export type OrderStatus = 
  | 'RECIBIDA'
  | 'EN PROCESO'
  | 'LISTA PARA ENTREGAR'
  | 'ENTREGADA'
  | 'CANCELADA';

export type ShoeType = 
  | 'zapatos_formales'
  | 'tenis_deportivos'
  | 'botas_cuero'
  | 'tacones'
  | 'sandalias'
  | 'mocasines'
  | 'botines'
  | 'otro';

export type PaymentMethod = 
  | 'EFECTIVO'
  | 'NEQUI'
  | 'DAVIPLATA'
  | 'TRANSFERENCIA'
  | 'TARJETA';

export type UserRole = 'ADMIN' | 'OPERARIO';

export interface StaffMember {
  id: string;
  name: string;
  role: UserRole;
  specialty?: string;
  phone?: string;
  active: boolean;
}

export interface Client {
  id: string;
  fullName: string;
  phone: string;
  notes?: string;
  createdAt: string;
  repairCount?: number;
}

export interface OrderServiceItem {
  serviceId: string;
  name: string;
  price: number; // in COP
  notes?: string;
}

export interface OrderPayment {
  id: string;
  date: string;
  amount: number; // in COP
  paymentMethod: PaymentMethod;
  reference?: string;
  registeredBy: string;
  notes?: string;
}

export interface StatusHistoryEntry {
  id: string;
  fromStatus?: OrderStatus;
  toStatus: OrderStatus;
  changedAt: string;
  changedBy: string;
  reason?: string;
}

export interface DeliveryDetails {
  deliveredAt: string;
  deliveredBy: string;
  receivedByName?: string;
  adminAuthorizedDebt?: boolean;
  adminAuthorizationReason?: string;
}

export interface RepairOrder {
  id: string; // Unique order code, e.g. "ORD-1001"
  clientId: string;
  clientName: string;
  clientPhone: string;
  receivedDate: string; // ISO date string
  estimatedDeliveryDate: string; // ISO date string
  shoeType: ShoeType;
  description: string;
  services: OrderServiceItem[];
  totalAmount: number;
  paidAmount: number;
  balanceAmount: number;
  lockerLocation: string; // Physical location / shelf, e.g. "Casillero A-12"
  assignedStaffId: string;
  assignedStaffName: string;
  observations?: string;
  photos: string[]; // Base64 data URLs or preview links
  dataPrivacyAuthorized: boolean; // Habeas Data Colombia Ley 1581
  status: OrderStatus;
  statusHistory: StatusHistoryEntry[];
  payments: OrderPayment[];
  deliveryDetails?: DeliveryDetails;
  createdAt: string;
  updatedAt: string;
}

export interface ServiceCatalogItem {
  id: string;
  name: string;
  description: string;
  category: 'suelas' | 'costura' | 'lustre' | 'ortopedia' | 'accesorios' | 'general';
  basePrice: number; // in COP
  estimatedHours: number;
  active: boolean;
}

export interface FinancialSummary {
  receivedCount: number;
  inProcessCount: number;
  readyCount: number;
  deliveredCount: number;
  cancelledCount: number;
  totalOrders: number;
  totalPendingBalance: number; // Total portfolio / balance to collect
  totalRevenueCollected: number; // Total money collected
  todayRevenue: number;
}

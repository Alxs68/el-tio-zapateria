import React from 'react';
import { StaffMember } from '../types';
import { 
  Wrench, 
  UserCheck, 
  Plus, 
  Search, 
  Info, 
  RotateCcw,
  BookOpen
} from 'lucide-react';

interface HeaderProps {
  activeTab: 'dashboard' | 'orders' | 'clients' | 'catalog' | 'reports';
  setActiveTab: (tab: 'dashboard' | 'orders' | 'clients' | 'catalog' | 'reports') => void;
  activeUser: StaffMember;
  staffList: StaffMember[];
  onSwitchUser: (staff: StaffMember) => void;
  onOpenNewOrder: () => void;
  onOpenQuickSearch: () => void;
  onOpenArchitectureModal: () => void;
  onOpenUserManual: () => void;
  onResetDemoData: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  activeUser,
  staffList,
  onSwitchUser,
  onOpenNewOrder,
  onOpenQuickSearch,
  onOpenArchitectureModal,
  onOpenUserManual,
  onResetDemoData,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-stone-900 text-stone-100 border-b border-stone-800 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between gap-4 h-16">
        
        {/* Zone 1: Single element brand mark */}
        <div className="flex items-center gap-3 shrink-0">
          <button 
            onClick={() => setActiveTab('dashboard')} 
            className="flex items-center gap-2 text-left group focus:outline-none"
          >
            <div className="w-9 h-9 rounded-lg bg-amber-600 flex items-center justify-center text-stone-950 font-bold shadow-inner">
              <Wrench className="w-5 h-5 text-stone-950" />
            </div>
            <div>
              <span className="text-base sm:text-lg font-bold tracking-tight text-white block leading-tight">
                Zapatería El Tío
              </span>
              <span className="text-[11px] text-amber-400 font-medium tracking-wide uppercase hidden sm:block">
                Taller de Calzado Artesanal
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Desktop Navigation Links (Clean single-line prose, no pills) */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-stone-300">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
              activeTab === 'dashboard' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : 'hover:text-white'
            }`}
          >
            Tablero Principal
          </button>
          <button
            onClick={() => setActiveTab('orders')}
            className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
              activeTab === 'orders' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : 'hover:text-white'
            }`}
          >
            Reparaciones
          </button>
          <button
            onClick={() => setActiveTab('clients')}
            className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
              activeTab === 'clients' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : 'hover:text-white'
            }`}
          >
            Clientes
          </button>
          <button
            onClick={() => setActiveTab('catalog')}
            className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
              activeTab === 'catalog' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : 'hover:text-white'
            }`}
          >
            Tarifas y Servicios
          </button>
          <button
            onClick={() => setActiveTab('reports')}
            className={`transition-colors whitespace-nowrap shrink-0 py-1 ${
              activeTab === 'reports' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : 'hover:text-white'
            }`}
          >
            Finanzas & Reportes
          </button>
        </nav>

        {/* Zone 3: Active User Switcher, Quick Actions & Primary CTA */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          
          {/* Quick Search Trigger */}
          <button
            onClick={onOpenQuickSearch}
            className="p-2 text-stone-300 hover:text-white hover:bg-stone-800 rounded-lg transition-colors flex items-center gap-1.5 text-xs"
            title="Buscar orden o cliente"
            aria-label="Buscar"
          >
            <Search className="w-4 h-4" />
            <span className="hidden xl:inline text-stone-400">Buscar...</span>
          </button>

          {/* User Role Switcher Dropdown */}
          <div className="flex items-center bg-stone-800 border border-stone-700 rounded-lg p-1 text-xs">
            <UserCheck className="w-3.5 h-3.5 text-amber-400 ml-1.5 mr-1" />
            <select
              value={activeUser.id}
              onChange={(e) => {
                const found = staffList.find((s) => s.id === e.target.value);
                if (found) onSwitchUser(found);
              }}
              className="bg-transparent text-stone-200 text-xs font-medium focus:outline-none cursor-pointer pr-1 py-1"
              title="Cambiar usuario activo para simular roles"
            >
              {staffList.map((staff) => (
                <option key={staff.id} value={staff.id} className="bg-stone-900 text-stone-100">
                  {staff.role === 'ADMIN' ? '👑 ' : '🛠️ '}
                  {staff.name.split(' ')[0]} ({staff.role})
                </option>
              ))}
            </select>
          </div>

          {/* User Manual / Guía button */}
          <button
            onClick={onOpenUserManual}
            className="p-2 text-stone-300 hover:text-white hover:bg-stone-800 rounded-lg transition-colors flex items-center gap-1.5 text-xs font-semibold"
            title="Manual de uso paso a paso para el taller"
            aria-label="Manual de uso"
          >
            <BookOpen className="w-4 h-4 text-amber-400" />
            <span className="hidden md:inline text-amber-300">Manual</span>
          </button>

          {/* Architecture / Info button */}
          <button
            onClick={onOpenArchitectureModal}
            className="p-2 text-stone-300 hover:text-white hover:bg-stone-800 rounded-lg transition-colors"
            title="Detalles técnicos, arquitectura y entrega"
            aria-label="Información del sistema"
          >
            <Info className="w-4 h-4 text-stone-400" />
          </button>

          {/* Primary Action CTA */}
          <button
            onClick={onOpenNewOrder}
            className="bg-amber-600 hover:bg-amber-500 active:bg-amber-700 text-stone-950 font-bold px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm flex items-center gap-1.5 shadow-sm transition-transform active:scale-95 whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Nueva Reparación</span>
            <span className="sm:hidden">Nueva</span>
          </button>
        </div>

      </div>
    </header>
  );
};

import React, { useState } from 'react';
import { 
  RepairOrder, 
  StaffMember, 
  OrderStatus, 
  PaymentMethod 
} from '../types';
import { 
  formatCOP, 
  formatDate, 
  formatDateTime, 
  getOrderStatusMeta, 
  getShoeTypeLabel, 
  canTransitionStatus,
  generateWhatsAppNotification 
} from '../utils/formatters';
import { 
  X, 
  CheckCircle, 
  Clock, 
  AlertTriangle, 
  DollarSign, 
  Phone, 
  MessageSquare, 
  Send, 
  Share2, 
  Copy, 
  Printer, 
  User, 
  MapPin, 
  Calendar, 
  ShieldAlert, 
  Check, 
  ArrowRight,
  History,
  Lock,
  ExternalLink
} from 'lucide-react';

interface OrderDetailsModalProps {
  order: RepairOrder | null;
  isOpen: boolean;
  onClose: () => void;
  activeUser: StaffMember;
  onUpdateStatus: (
    orderId: string, 
    newStatus: OrderStatus, 
    reason?: string,
    deliveryDetails?: {
      deliveredBy: string;
      receivedByName?: string;
      adminAuthorizedDebt?: boolean;
      adminAuthorizationReason?: string;
    }
  ) => void;
  onAddPayment: (
    orderId: string,
    payment: {
      amount: number;
      paymentMethod: PaymentMethod;
      reference?: string;
      notes?: string;
    }
  ) => void;
}

export const OrderDetailsModal: React.FC<OrderDetailsModalProps> = ({
  order,
  isOpen,
  onClose,
  activeUser,
  onUpdateStatus,
  onAddPayment,
}) => {
  if (!isOpen || !order) return null;

  const [activeTab, setActiveTab] = useState<'info' | 'payments' | 'history' | 'notifications' | 'receipt'>('info');
  
  // Payment recording state
  const [paymentAmount, setPaymentAmount] = useState<number>(order.balanceAmount);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('EFECTIVO');
  const [paymentReference, setPaymentReference] = useState('');
  const [paymentNotes, setPaymentNotes] = useState('');
  const [isSubmittingPayment, setIsSubmittingPayment] = useState(false);
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [paymentSuccessMsg, setPaymentSuccessMsg] = useState<string | null>(null);

  // Status transition state
  const [transitionError, setTransitionError] = useState<string | null>(null);
  const [showAdminExceptionModal, setShowAdminExceptionModal] = useState(false);
  const [adminExceptionReason, setAdminExceptionReason] = useState('');

  // Copy notification state
  const [copiedNotification, setCopiedNotification] = useState(false);

  const isAdmin = activeUser.role === 'ADMIN';
  const statusMeta = getOrderStatusMeta(order.status);
  const hasPendingBalance = order.balanceAmount > 0;

  // Handle Status change request
  const handleRequestStatusChange = (targetStatus: OrderStatus) => {
    setTransitionError(null);

    // Business check: If trying to mark as ENTREGADA with pending balance
    if (targetStatus === 'ENTREGADA' && hasPendingBalance) {
      if (!isAdmin) {
        setTransitionError(
          `Acción bloqueada: No se puede entregar calzado con saldo pendiente de ${formatCOP(order.balanceAmount)}. Se requiere el pago total o la autorización de un Administrador.`
        );
        return;
      } else {
        // Show Admin Exception modal
        setShowAdminExceptionModal(true);
        return;
      }
    }

    const check = canTransitionStatus(order.status, targetStatus, order.balanceAmount, isAdmin);
    if (!check.allowed) {
      setTransitionError(check.reason || 'Transición no permitida.');
      return;
    }

    onUpdateStatus(order.id, targetStatus, `Cambio de estado a ${targetStatus} registrado por ${activeUser.name}`);
  };

  // Handle Admin Authorization of Delivery with Debt
  const handleConfirmAdminException = () => {
    if (!adminExceptionReason.trim()) {
      setTransitionError('Debe ingresar el motivo de la autorización expresa del saldo pendiente.');
      return;
    }

    onUpdateStatus(
      order.id,
      'ENTREGADA',
      `Entrega autorizada con deuda de ${formatCOP(order.balanceAmount)}. Motivo: ${adminExceptionReason}`,
      {
        deliveredBy: activeUser.name,
        receivedByName: order.clientName,
        adminAuthorizedDebt: true,
        adminAuthorizationReason: adminExceptionReason.trim(),
      }
    );

    setShowAdminExceptionModal(false);
  };

  // Handle Recording New Payment
  const handleRecordPayment = (e: React.FormEvent) => {
    e.preventDefault();
    setPaymentError(null);
    setPaymentSuccessMsg(null);

    if (isSubmittingPayment) return; // Prevent double submit
    if (paymentAmount <= 0) {
      setPaymentError('El valor del pago debe ser mayor a cero.');
      return;
    }
    if (paymentAmount > order.balanceAmount) {
      setPaymentError(`El valor no puede superar el saldo pendiente (${formatCOP(order.balanceAmount)}).`);
      return;
    }

    setIsSubmittingPayment(true);
    try {
      onAddPayment(order.id, {
        amount: paymentAmount,
        paymentMethod,
        reference: paymentReference.trim() || undefined,
        notes: paymentNotes.trim() || undefined,
      });

      setPaymentSuccessMsg(`Pago de ${formatCOP(paymentAmount)} registrado exitosamente.`);
      setPaymentAmount(Math.max(0, order.balanceAmount - paymentAmount));
      setPaymentReference('');
      setPaymentNotes('');
    } catch (err: any) {
      setPaymentError(err.message || 'Error al registrar el pago.');
    } finally {
      setIsSubmittingPayment(false);
    }
  };

  // WhatsApp Notifications
  const notifRecepcion = generateWhatsAppNotification(order, 'RECEPCION');
  const notifLista = generateWhatsAppNotification(order, 'LISTA');
  const notifEntrega = generateWhatsAppNotification(order, 'ENTREGA');

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedNotification(true);
    setTimeout(() => setCopiedNotification(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-stone-200 overflow-hidden my-auto max-h-[94vh] flex flex-col">
        
        {/* Top Header */}
        <div className="bg-stone-900 text-stone-100 px-5 py-3.5 flex items-center justify-between border-b border-stone-800 shrink-0">
          <div className="flex items-center gap-2 sm:gap-3">
            <span className="bg-amber-600 text-stone-950 text-xs sm:text-sm font-mono font-extrabold px-2.5 py-0.5 rounded">
              {order.id}
            </span>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white tracking-tight">
                {order.clientName}
              </h2>
              <span className="text-[11px] text-stone-400 block sm:inline">
                {getShoeTypeLabel(order.shoeType)} · {order.lockerLocation}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className={`px-2.5 py-1 text-xs font-bold rounded-md border ${statusMeta.badgeBg} ${statusMeta.badgeText} ${statusMeta.borderColor}`}>
              {statusMeta.label}
            </span>
            <button
              onClick={onClose}
              className="text-stone-400 hover:text-white p-1 rounded-lg transition-colors ml-2"
              aria-label="Cerrar"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation in Sheet */}
        <div className="bg-stone-100 border-b border-stone-200 px-4 flex items-center gap-2 overflow-x-auto scroll-touch shrink-0">
          <button
            onClick={() => setActiveTab('info')}
            className={`py-2.5 px-3 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 ${
              activeTab === 'info'
                ? 'border-amber-600 text-stone-950 font-bold'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            Detalles & Estado
          </button>
          <button
            onClick={() => setActiveTab('payments')}
            className={`py-2.5 px-3 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 flex items-center gap-1.5 ${
              activeTab === 'payments'
                ? 'border-amber-600 text-stone-950 font-bold'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            <span>Abonos & Pagos</span>
            {hasPendingBalance && (
              <span className="bg-red-100 text-red-700 text-[10px] font-bold px-1.5 py-0.2 rounded-full">
                Debe {formatCOP(order.balanceAmount)}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('notifications')}
            className={`py-2.5 px-3 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 flex items-center gap-1 ${
              activeTab === 'notifications'
                ? 'border-amber-600 text-stone-950 font-bold'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
            <span>Notificar (WhatsApp)</span>
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`py-2.5 px-3 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 flex items-center gap-1 ${
              activeTab === 'history'
                ? 'border-amber-600 text-stone-950 font-bold'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Historial ({order.statusHistory.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('receipt')}
            className={`py-2.5 px-3 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 flex items-center gap-1 ${
              activeTab === 'receipt'
                ? 'border-amber-600 text-stone-950 font-bold'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Ticket Taller</span>
          </button>
        </div>

        {/* Tab 1: General Info & Status Workflow */}
        {activeTab === 'info' && (
          <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1 text-xs sm:text-sm">
            
            {transitionError && (
              <div className="p-3.5 bg-red-50 border border-red-300 rounded-xl text-red-800 text-xs flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
                <div className="flex-1">
                  <p className="font-bold">{transitionError}</p>
                  {hasPendingBalance && order.status !== 'ENTREGADA' && (
                    <button
                      onClick={() => setActiveTab('payments')}
                      className="mt-1 text-red-900 underline font-semibold text-xs inline-block"
                    >
                      Ir a registrar pago de {formatCOP(order.balanceAmount)} →
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Workflow Transition Stepper */}
            <div className="bg-stone-50 p-4 rounded-xl border border-stone-200">
              <span className="text-[11px] font-bold text-stone-600 uppercase tracking-wider block mb-3">
                Cambio de Estado de la Reparación
              </span>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                
                {/* 1. RECIBIDA */}
                <button
                  onClick={() => handleRequestStatusChange('RECIBIDA')}
                  disabled={order.status === 'RECIBIDA'}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    order.status === 'RECIBIDA'
                      ? 'bg-amber-100 border-amber-400 font-bold text-amber-950 shadow-xs'
                      : 'bg-white border-stone-200 text-stone-600 hover:border-amber-300'
                  }`}
                >
                  <span className="text-[10px] text-stone-600 uppercase block">Paso 1</span>
                  <span className="text-xs font-bold block mt-0.5">Recibida</span>
                </button>

                {/* 2. EN PROCESO */}
                <button
                  onClick={() => handleRequestStatusChange('EN PROCESO')}
                  disabled={order.status === 'EN PROCESO'}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    order.status === 'EN PROCESO'
                      ? 'bg-blue-100 border-blue-400 font-bold text-blue-950 shadow-xs'
                      : 'bg-white border-stone-200 text-stone-600 hover:border-blue-300'
                  }`}
                >
                  <span className="text-[10px] text-stone-600 uppercase block">Paso 2</span>
                  <span className="text-xs font-bold block mt-0.5">En Proceso</span>
                </button>

                {/* 3. LISTA PARA ENTREGAR */}
                <button
                  onClick={() => handleRequestStatusChange('LISTA PARA ENTREGAR')}
                  disabled={order.status === 'LISTA PARA ENTREGAR'}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    order.status === 'LISTA PARA ENTREGAR'
                      ? 'bg-emerald-100 border-emerald-400 font-bold text-emerald-950 shadow-xs'
                      : 'bg-white border-stone-200 text-stone-600 hover:border-emerald-300'
                  }`}
                >
                  <span className="text-[10px] text-stone-600 uppercase block">Paso 3</span>
                  <span className="text-xs font-bold block mt-0.5">Lista p/ Entrega</span>
                </button>

                {/* 4. ENTREGADA */}
                <button
                  onClick={() => handleRequestStatusChange('ENTREGADA')}
                  disabled={order.status === 'ENTREGADA'}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    order.status === 'ENTREGADA'
                      ? 'bg-stone-800 border-stone-900 font-bold text-white shadow-xs'
                      : 'bg-white border-stone-200 text-stone-600 hover:border-stone-400'
                  }`}
                >
                  <span className="text-[10px] text-stone-600 uppercase block">Final</span>
                  <span className="text-xs font-bold block mt-0.5 flex items-center justify-between">
                    <span>Entregada</span>
                    {hasPendingBalance && (
                      <span title="Saldo pendiente">
                        <Lock className="w-3 h-3 text-red-500" />
                      </span>
                    )}
                  </span>
                </button>

              </div>

              {/* Status explanation note */}
              <p className="text-[11px] text-stone-500 mt-2.5 italic">
                {statusMeta.description}
              </p>
            </div>

            {/* Client & Workshop Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Client Box */}
              <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                <span className="text-[10px] font-bold text-stone-600 uppercase tracking-wider block">
                  Cliente del Calzado
                </span>
                <div className="text-sm font-bold text-stone-900">{order.clientName}</div>
                <div className="flex items-center justify-between text-xs text-stone-600">
                  <div className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-stone-500" />
                    <span>{order.clientPhone}</span>
                  </div>
                  <a
                    href={`tel:${order.clientPhone}`}
                    className="text-amber-800 hover:text-amber-900 font-semibold text-xs"
                  >
                    Llamar
                  </a>
                </div>
                <div className="pt-2 border-t border-stone-200 text-xs text-stone-600 flex items-center justify-between">
                  <span>Autorización Habeas Data:</span>
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <Check className="w-3 h-3" /> Aprobada
                  </span>
                </div>
              </div>

              {/* Workshop Logistics Box */}
              <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                <span className="text-[10px] font-bold text-stone-600 uppercase tracking-wider block">
                  Ubicación & Responsable
                </span>
                <div className="flex items-center gap-2 text-xs">
                  <MapPin className="w-4 h-4 text-amber-600 shrink-0" />
                  <span className="font-bold text-amber-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                    {order.lockerLocation}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs text-stone-600">
                  <User className="w-3.5 h-3.5 text-stone-500 shrink-0" />
                  <span>Maestro asignado: <strong>{order.assignedStaffName}</strong></span>
                </div>
                <div className="flex items-center gap-2 text-xs text-stone-600">
                  <Calendar className="w-3.5 h-3.5 text-stone-500 shrink-0" />
                  <span>Promesa de entrega: <strong>{formatDate(order.estimatedDeliveryDate)}</strong></span>
                </div>
              </div>

            </div>

            {/* Description & Observations */}
            <div className="space-y-2">
              <span className="text-[10px] font-bold text-stone-600 uppercase tracking-wider block">
                Descripción del Trabajo
              </span>
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-stone-800 text-xs sm:text-sm">
                {order.description}
              </div>
              {order.observations && (
                <div className="p-2.5 bg-amber-50/60 rounded-lg border border-amber-200 text-amber-900 text-xs">
                  <strong>Observaciones técnicas de recepción:</strong> {order.observations}
                </div>
              )}
            </div>

            {/* Services Contracted List */}
            <div className="space-y-2">
              <span className="text-[10px] font-bold text-stone-600 uppercase tracking-wider block">
                Servicios Realizados
              </span>
              <div className="border border-stone-200 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-100 border-b border-stone-200 text-stone-600 font-semibold">
                    <tr>
                      <th className="py-2 px-3">Servicio</th>
                      <th className="py-2 px-3 text-right">Tarifa (COP)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-200 bg-white">
                    {order.services.map((item, i) => (
                      <tr key={i}>
                        <td className="py-2 px-3 font-medium text-stone-900">{item.name}</td>
                        <td className="py-2 px-3 text-right font-mono font-bold text-stone-900 tabular-nums">
                          {formatCOP(item.price)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-stone-50 font-bold border-t border-stone-200">
                    <tr>
                      <td className="py-2 px-3 text-stone-800">Total Reparación:</td>
                      <td className="py-2 px-3 text-right font-mono text-stone-950 tabular-nums">
                        {formatCOP(order.totalAmount)}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

            {/* Calzado Photos Gallery */}
            {order.photos && order.photos.length > 0 && (
              <div className="space-y-2">
                <span className="text-[10px] font-bold text-stone-600 uppercase tracking-wider block">
                  Evidencia Fotográfica del Calzado ({order.photos.length})
                </span>
                <div className="flex flex-wrap gap-2.5">
                  {order.photos.map((photo, idx) => (
                    <div key={idx} className="w-24 h-24 rounded-xl overflow-hidden border border-stone-300 shadow-xs">
                      <img
                        src={photo}
                        alt={`Foto calzado ${idx + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Delivery Details Banner if already Delivered */}
            {order.status === 'ENTREGADA' && order.deliveryDetails && (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-1 text-xs">
                <div className="flex items-center gap-1.5 font-bold text-emerald-900 text-sm">
                  <CheckCircle className="w-4 h-4 text-emerald-700" />
                  <span>Calzado Entregado al Cliente</span>
                </div>
                <div className="text-emerald-800">
                  Fecha y hora: {formatDateTime(order.deliveryDetails.deliveredAt)}
                </div>
                <div className="text-emerald-800">
                  Entregado por: <strong>{order.deliveryDetails.deliveredBy}</strong>
                </div>
                {order.deliveryDetails.adminAuthorizedDebt && (
                  <div className="mt-2 p-2 bg-amber-100/80 rounded border border-amber-300 text-amber-900 font-medium">
                    ⚠️ <strong>Excepción de Administrador:</strong> Entregado con saldo pendiente autorizado.
                    <br />
                    <em>Motivo: {order.deliveryDetails.adminAuthorizationReason}</em>
                  </div>
                )}
              </div>
            )}

          </div>
        )}

        {/* Tab 2: Payments & Balance Ledger */}
        {activeTab === 'payments' && (
          <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1 text-xs sm:text-sm">
            
            {/* Balance Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-4 bg-stone-50 rounded-xl border border-stone-200">
                <span className="text-[10px] text-stone-600 uppercase font-semibold block">Total Orden</span>
                <span className="text-lg sm:text-xl font-bold text-stone-900 tabular-nums">
                  {formatCOP(order.totalAmount)}
                </span>
              </div>
              <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200">
                <span className="text-[10px] text-emerald-800 uppercase font-semibold block">Total Abonado</span>
                <span className="text-lg sm:text-xl font-bold text-emerald-800 tabular-nums">
                  {formatCOP(order.paidAmount)}
                </span>
              </div>
              <div className={`p-4 rounded-xl border ${hasPendingBalance ? 'bg-red-50 border-red-200' : 'bg-stone-50 border-stone-200'}`}>
                <span className={`text-[10px] uppercase font-semibold block ${hasPendingBalance ? 'text-red-700' : 'text-stone-600'}`}>
                  Saldo Pendiente
                </span>
                <span className={`text-lg sm:text-xl font-extrabold tabular-nums ${hasPendingBalance ? 'text-red-600' : 'text-emerald-700'}`}>
                  {formatCOP(order.balanceAmount)}
                </span>
              </div>
            </div>

            {/* Record New Payment Form (Only if balance > 0) */}
            {hasPendingBalance ? (
              <form onSubmit={handleRecordPayment} className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-900 uppercase tracking-wide">
                    Registrar Nuevo Abono o Cancelación
                  </span>
                  <span className="text-xs text-stone-600 font-medium">
                    Operario: <strong>{activeUser.name}</strong>
                  </span>
                </div>

                {paymentError && (
                  <div className="p-2.5 bg-red-50 border border-red-200 rounded text-red-700 text-xs">
                    {paymentError}
                  </div>
                )}
                {paymentSuccessMsg && (
                  <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded text-emerald-800 text-xs">
                    {paymentSuccessMsg}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Monto a Pagar (COP) *</label>
                    <div className="flex items-center gap-1.5">
                      <span className="text-stone-500 font-bold">$</span>
                      <input
                        type="number"
                        min="1000"
                        max={order.balanceAmount}
                        step="1000"
                        value={paymentAmount}
                        onChange={(e) => setPaymentAmount(Math.min(order.balanceAmount, Math.max(0, Number(e.target.value))))}
                        className="w-full px-3 py-1.5 bg-white border border-stone-300 rounded-lg text-xs font-bold text-stone-900 tabular-nums focus:outline-none focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => setPaymentAmount(order.balanceAmount)}
                      className="mt-1 text-[10px] text-amber-700 hover:underline font-semibold"
                    >
                      Pagar totalidad ({formatCOP(order.balanceAmount)})
                    </button>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Método de Pago *</label>
                    <select
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                      className="w-full px-3 py-1.5 bg-white border border-stone-300 rounded-lg text-xs font-medium focus:outline-none focus:ring-2 focus:ring-amber-500"
                    >
                      <option value="EFECTIVO">Efectivo en mostrador</option>
                      <option value="NEQUI">Nequi</option>
                      <option value="DAVIPLATA">Daviplata</option>
                      <option value="TRANSFERENCIA">Transferencia Bancaria</option>
                      <option value="TARJETA">Tarjeta Débito/Crédito</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Referencia / Comprobante</label>
                    <input
                      type="text"
                      placeholder="Ej. Nro. transacción Nequi"
                      value={paymentReference}
                      onChange={(e) => setPaymentReference(e.target.value)}
                      className="w-full px-3 py-1.5 bg-white border border-stone-300 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <input
                    type="text"
                    placeholder="Nota sobre el pago (opcional)"
                    value={paymentNotes}
                    onChange={(e) => setPaymentNotes(e.target.value)}
                    className="w-2/3 px-3 py-1.5 bg-white border border-stone-300 rounded-lg text-xs"
                  />
                  <button
                    type="submit"
                    disabled={isSubmittingPayment}
                    className="px-4 py-2 bg-emerald-700 hover:bg-emerald-600 disabled:opacity-50 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 transition-all shadow-xs"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Confirmar Pago</span>
                  </button>
                </div>
              </form>
            ) : (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-center space-y-1">
                <CheckCircle className="w-7 h-7 text-emerald-600 mx-auto" />
                <h4 className="text-sm font-bold text-emerald-950">Orden Totalmente Cancelada</h4>
                <p className="text-xs text-emerald-700">El cliente no tiene saldos pendientes por este trabajo.</p>
              </div>
            )}

            {/* Payments History Ledger Table */}
            <div className="space-y-2">
              <span className="text-[10px] font-bold text-stone-600 uppercase tracking-wider block">
                Historial de Pagos y Abonos Registrados
              </span>
              <div className="border border-stone-200 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-100 border-b border-stone-200 text-stone-600 font-semibold">
                    <tr>
                      <th className="py-2 px-3">Fecha y Hora</th>
                      <th className="py-2 px-3">Método</th>
                      <th className="py-2 px-3">Registrado Por</th>
                      <th className="py-2 px-3 text-right">Valor (COP)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-200 bg-white">
                    {order.payments.map((p) => (
                      <tr key={p.id}>
                        <td className="py-2.5 px-3 text-stone-700">{formatDateTime(p.date)}</td>
                        <td className="py-2.5 px-3">
                          <span className="font-semibold text-stone-900">{p.paymentMethod}</span>
                          {p.reference && <span className="text-[10px] text-stone-500 block">Ref: {p.reference}</span>}
                        </td>
                        <td className="py-2.5 px-3 text-stone-600">{p.registeredBy}</td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-700 tabular-nums">
                          +{formatCOP(p.amount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* Tab 3: Customer Notifications (WhatsApp & SMS) */}
        {activeTab === 'notifications' && (
          <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1 text-xs sm:text-sm">
            
            {/* Technical Transparency Disclaimer */}
            <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl text-amber-900 text-xs space-y-1">
              <p className="font-bold flex items-center gap-1.5">
                <span>📱 Integración de Mensajería para el Taller</span>
              </p>
              <p className="text-stone-700 leading-relaxed">
                Esta función genera mensajes pre-construidos en español con todos los datos de la orden y abre directamente la conversación en WhatsApp Web o en la app móvil del cliente con un solo clic. Para envíos automáticos desatendidos en segundo plano (sin intervención del operario), se requeriría configurar la API oficial de WhatsApp Cloud de Meta o una pasarela de SMS.
              </p>
            </div>

            {/* Template 1: Recepción de Orden */}
            <div className="p-4 bg-white border border-stone-200 rounded-xl space-y-2.5 shadow-2xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-stone-900 uppercase">
                  1. Notificación de Calzado Recibido
                </span>
                <span className="text-[11px] text-stone-500">Al registrar la orden</span>
              </div>
              <div className="bg-stone-50 p-3 rounded-lg border border-stone-200 text-stone-700 font-mono text-[11px] whitespace-pre-wrap">
                {notifRecepcion.message}
              </div>
              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => copyToClipboard(notifRecepcion.message)}
                  className="px-3 py-1.5 border border-stone-300 rounded-lg text-xs font-semibold text-stone-700 hover:bg-stone-100 flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copiar</span>
                </button>
                <a
                  href={notifRecepcion.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 shadow-2xs"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Enviar por WhatsApp</span>
                </a>
              </div>
            </div>

            {/* Template 2: Reparación Lista */}
            <div className="p-4 bg-white border border-stone-200 rounded-xl space-y-2.5 shadow-2xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-stone-900 uppercase">
                  2. Notificación de Reparación Lista para Retiro
                </span>
                <span className="text-[11px] text-emerald-700 font-semibold">Al terminar el trabajo</span>
              </div>
              <div className="bg-stone-50 p-3 rounded-lg border border-stone-200 text-stone-700 font-mono text-[11px] whitespace-pre-wrap">
                {notifLista.message}
              </div>
              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => copyToClipboard(notifLista.message)}
                  className="px-3 py-1.5 border border-stone-300 rounded-lg text-xs font-semibold text-stone-700 hover:bg-stone-100 flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copiar</span>
                </button>
                <a
                  href={notifLista.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 shadow-2xs"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Enviar por WhatsApp</span>
                </a>
              </div>
            </div>

            {/* Template 3: Calzado Entregado */}
            <div className="p-4 bg-white border border-stone-200 rounded-xl space-y-2.5 shadow-2xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-stone-900 uppercase">
                  3. Agradecimiento de Entrega & Garantía
                </span>
                <span className="text-[11px] text-stone-500">Al entregar al cliente</span>
              </div>
              <div className="bg-stone-50 p-3 rounded-lg border border-stone-200 text-stone-700 font-mono text-[11px] whitespace-pre-wrap">
                {notifEntrega.message}
              </div>
              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => copyToClipboard(notifEntrega.message)}
                  className="px-3 py-1.5 border border-stone-300 rounded-lg text-xs font-semibold text-stone-700 hover:bg-stone-100 flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copiar</span>
                </button>
                <a
                  href={notifEntrega.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 shadow-2xs"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Enviar por WhatsApp</span>
                </a>
              </div>
            </div>

            {copiedNotification && (
              <div className="fixed bottom-6 right-6 z-50 bg-stone-900 text-white text-xs px-4 py-2 rounded-lg shadow-lg">
                Mensaje copiado al portapapeles ✓
              </div>
            )}

          </div>
        )}

        {/* Tab 4: Audit & Status History */}
        {activeTab === 'history' && (
          <div className="p-5 sm:p-6 overflow-y-auto space-y-4 flex-1 text-xs sm:text-sm">
            <span className="text-[11px] font-bold text-stone-600 uppercase tracking-wider block">
              Registro de Auditoría de Cambios
            </span>
            <div className="relative border-l-2 border-stone-200 pl-4 ml-2 space-y-5">
              {order.statusHistory.map((h, i) => (
                <div key={h.id || i} className="relative">
                  {/* Dot */}
                  <div className="absolute -left-[21px] top-1 w-3 h-3 rounded-full bg-amber-600 border-2 border-white shadow-xs" />
                  
                  <div className="flex items-center gap-2 text-stone-500 text-[11px]">
                    <Clock className="w-3 h-3" />
                    <span>{formatDateTime(h.changedAt)}</span>
                    <span aria-hidden="true">·</span>
                    <strong className="text-stone-800">{h.changedBy}</strong>
                  </div>

                  <div className="mt-1 flex items-center gap-2">
                    {h.fromStatus && (
                      <>
                        <span className="font-semibold text-stone-600">{h.fromStatus}</span>
                        <ArrowRight className="w-3 h-3 text-stone-400" />
                      </>
                    )}
                    <span className="font-extrabold text-stone-900">{h.toStatus}</span>
                  </div>

                  {h.reason && (
                    <p className="text-xs text-stone-600 mt-1 bg-stone-50 p-2 rounded-md border border-stone-100">
                      {h.reason}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 5: Workshop Ticket / Printable Receipt */}
        {activeTab === 'receipt' && (
          <div className="p-5 sm:p-6 overflow-y-auto space-y-4 flex-1 text-xs">
            <div className="max-w-md mx-auto bg-stone-50 p-5 rounded-xl border border-stone-300 font-mono space-y-3">
              <div className="text-center border-b border-dashed border-stone-400 pb-3">
                <h3 className="font-bold text-sm tracking-tight text-stone-900">ZAPATERÍA EL TÍO</h3>
                <p className="text-[10px] text-stone-600">NIT: 71.345.890-2 · Taller de Calzado</p>
                <p className="text-[10px] text-stone-600">Medellín / Colombia · Cel: 310 456 7890</p>
                <div className="mt-2 text-xs font-bold bg-stone-900 text-white py-1 px-3 rounded inline-block">
                  ORDEN: {order.id}
                </div>
              </div>

              <div className="text-[11px] space-y-1">
                <div><strong>Cliente:</strong> {order.clientName}</div>
                <div><strong>Teléfono:</strong> {order.clientPhone}</div>
                <div><strong>Fecha:</strong> {formatDateTime(order.receivedDate)}</div>
                <div><strong>Entrega prometida:</strong> {formatDate(order.estimatedDeliveryDate)}</div>
                <div className="bg-amber-100 p-1.5 rounded font-bold text-amber-900">
                  UBICACIÓN: {order.lockerLocation}
                </div>
                <div><strong>Calzado:</strong> {getShoeTypeLabel(order.shoeType)}</div>
                <div><strong>Trabajo:</strong> {order.description}</div>
              </div>

              <div className="border-t border-b border-dashed border-stone-400 py-2 space-y-1 text-[11px]">
                {order.services.map((s, idx) => (
                  <div key={idx} className="flex justify-between">
                    <span>{s.name}</span>
                    <span>{formatCOP(s.price)}</span>
                  </div>
                ))}
              </div>

              <div className="space-y-1 text-right text-[11px]">
                <div>TOTAL: <strong className="text-xs">{formatCOP(order.totalAmount)}</strong></div>
                <div>ABONADO: <strong className="text-emerald-700">{formatCOP(order.paidAmount)}</strong></div>
                <div className="text-xs font-bold text-red-600">
                  SALDO A PAGAR: {formatCOP(order.balanceAmount)}
                </div>
              </div>

              <div className="text-[9px] text-stone-500 text-center border-t border-dashed border-stone-400 pt-3">
                No respondemos por calzado después de 60 días.
                <br />
                Garantía artesanal de 30 días en costuras y pegas.
              </div>
            </div>

            <div className="text-center">
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 bg-stone-800 hover:bg-stone-900 text-white rounded-lg text-xs font-bold inline-flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Imprimir Ticket / Comprobante</span>
              </button>
            </div>
          </div>
        )}

        {/* Admin Delivery Debt Exception Modal */}
        {showAdminExceptionModal && (
          <div className="fixed inset-0 z-60 bg-black/70 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-md w-full p-5 space-y-4 border border-stone-300 shadow-2xl">
              <div className="flex items-center gap-2 text-amber-700 font-bold text-sm">
                <ShieldAlert className="w-5 h-5 text-amber-600" />
                <span>Autorización Excepcional de Administrador</span>
              </div>
              <p className="text-xs text-stone-700 leading-relaxed">
                Esta orden tiene un saldo pendiente de <strong>{formatCOP(order.balanceAmount)}</strong>. Según las políticas del taller, no se puede entregar calzado con saldo pendiente a menos que un Administrador asuma la autorización registrada.
              </p>
              <div>
                <label className="block text-xs font-semibold text-stone-800 mb-1">
                  Motivo o Justificación de la Entrega a Crédito *
                </label>
                <textarea
                  rows={3}
                  value={adminExceptionReason}
                  onChange={(e) => setAdminExceptionReason(e.target.value)}
                  placeholder="Ej. Cliente frecuente conocido, se compromete a transferir por Nequi en horas de la tarde..."
                  className="w-full p-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAdminExceptionModal(false)}
                  className="px-3 py-1.5 border border-stone-300 rounded-lg text-xs font-semibold text-stone-600"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmAdminException}
                  className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold rounded-lg text-xs shadow-xs"
                >
                  Autorizar Entrega
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

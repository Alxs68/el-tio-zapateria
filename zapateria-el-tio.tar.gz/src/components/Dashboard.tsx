import React, { useState } from 'react';
import { 
  RepairOrder, 
  FinancialSummary, 
  OrderStatus 
} from '../types';
import { 
  formatCOP, 
  formatCOPSimple, 
  formatDate, 
  getOrderStatusMeta, 
  getShoeTypeLabel 
} from '../utils/formatters';
import { 
  Inbox, 
  Cog, 
  CheckCircle2, 
  Truck, 
  DollarSign, 
  Search, 
  PlusCircle, 
  MapPin, 
  Calendar, 
  User, 
  Phone, 
  ChevronRight,
  Sparkles,
  TrendingUp,
  AlertCircle,
  BookOpen
} from 'lucide-react';

interface DashboardProps {
  orders: RepairOrder[];
  summary: FinancialSummary;
  onOpenOrder: (order: RepairOrder) => void;
  onOpenNewOrder: () => void;
  onSearchOrders: () => void;
  onOpenUserManual?: () => void;
  onQuickFilterStatus?: (status: OrderStatus | 'ALL') => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  orders,
  summary,
  onOpenOrder,
  onOpenNewOrder,
  onSearchOrders,
  onOpenUserManual,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<OrderStatus | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Filter orders
  const filteredOrders = orders.filter((ord) => {
    const matchesStatus = selectedFilter === 'ALL' || ord.status === selectedFilter;
    const cleanQuery = searchQuery.trim().toLowerCase();
    if (!cleanQuery) return matchesStatus;

    const matchesSearch =
      ord.id.toLowerCase().includes(cleanQuery) ||
      ord.clientName.toLowerCase().includes(cleanQuery) ||
      ord.clientPhone.includes(cleanQuery) ||
      ord.lockerLocation.toLowerCase().includes(cleanQuery) ||
      ord.description.toLowerCase().includes(cleanQuery);

    return matchesStatus && matchesSearch;
  });

  return (
    <div className="space-y-6 pb-20 lg:pb-8">
      
      {/* Hero Workshop Banner & Quick Actions */}
      <div className="bg-stone-900 text-stone-100 rounded-2xl p-5 sm:p-7 shadow-sm border border-stone-800 relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold tracking-wider uppercase mb-2">
            <span>Taller Don Tío</span>
            <span aria-hidden="true">·</span>
            <span>Reparación Artesanal & Ortopedia</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2 leading-tight">
            Control de Órdenes y Taller
          </h1>
          <p className="text-stone-300 text-sm leading-relaxed mb-5">
            Administra la recepción de calzado, seguimiento en casilleros, abonos y entregas en pesos colombianos.
          </p>
          
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenNewOrder}
              className="bg-amber-600 hover:bg-amber-500 active:bg-amber-700 text-stone-950 font-bold px-4 py-2.5 rounded-xl text-sm flex items-center gap-2 shadow-md transition-transform active:scale-95"
            >
              <PlusCircle className="w-4 h-4 text-stone-950" />
              <span>Registrar Nueva Reparación</span>
            </button>
            <button
              onClick={onSearchOrders}
              className="bg-stone-800 hover:bg-stone-700 active:bg-stone-800 text-stone-200 border border-stone-700 font-medium px-4 py-2.5 rounded-xl text-sm flex items-center gap-2 transition-colors"
            >
              <Search className="w-4 h-4 text-amber-400" />
              <span>Consultar por Ticket / Teléfono</span>
            </button>
            {onOpenUserManual && (
              <button
                onClick={onOpenUserManual}
                className="bg-stone-800/80 hover:bg-stone-800 text-amber-300 border border-amber-500/30 font-semibold px-3.5 py-2.5 rounded-xl text-xs sm:text-sm flex items-center gap-1.5 transition-colors"
                title="Ver manual de uso paso a paso"
              >
                <BookOpen className="w-4 h-4 text-amber-400" />
                <span>📘 Guía Rápida para el Taller</span>
              </button>
            )}
          </div>
        </div>

        {/* Decorative artisan background watermark */}
        <div className="absolute right-4 bottom-2 opacity-5 pointer-events-none hidden sm:block">
          <Sparkles className="w-48 h-48 text-white" />
        </div>
      </div>

      {/* KPI Metric Cards Grid - 6 Key Indicators */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        
        {/* Metric 1: Recibidas */}
        <button
          onClick={() => setSelectedFilter('RECIBIDA')}
          className={`text-left p-4 rounded-xl border transition-all ${
            selectedFilter === 'RECIBIDA'
              ? 'bg-amber-50 border-amber-400 ring-2 ring-amber-400/20 shadow-sm'
              : 'bg-white border-stone-200 hover:border-amber-300'
          }`}
        >
          <div className="flex items-center justify-between text-stone-600 mb-1">
            <span className="text-xs font-medium">Recibidas</span>
            <Inbox className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-stone-900 tabular-nums">
            {summary.receivedCount}
          </div>
          <p className="text-[11px] text-stone-600 mt-1">Por iniciar</p>
        </button>

        {/* Metric 2: En Proceso */}
        <button
          onClick={() => setSelectedFilter('EN PROCESO')}
          className={`text-left p-4 rounded-xl border transition-all ${
            selectedFilter === 'EN PROCESO'
              ? 'bg-blue-50 border-blue-400 ring-2 ring-blue-400/20 shadow-sm'
              : 'bg-white border-stone-200 hover:border-blue-300'
          }`}
        >
          <div className="flex items-center justify-between text-stone-600 mb-1">
            <span className="text-xs font-medium">En Proceso</span>
            <Cog className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-stone-900 tabular-nums">
            {summary.inProcessCount}
          </div>
          <p className="text-[11px] text-stone-600 mt-1">En el banco</p>
        </button>

        {/* Metric 3: Listas para Entregar */}
        <button
          onClick={() => setSelectedFilter('LISTA PARA ENTREGAR')}
          className={`text-left p-4 rounded-xl border transition-all ${
            selectedFilter === 'LISTA PARA ENTREGAR'
              ? 'bg-emerald-50 border-emerald-400 ring-2 ring-emerald-400/20 shadow-sm'
              : 'bg-white border-stone-200 hover:border-emerald-300'
          }`}
        >
          <div className="flex items-center justify-between text-stone-600 mb-1">
            <span className="text-xs font-medium">Listas</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-stone-900 tabular-nums">
            {summary.readyCount}
          </div>
          <p className="text-[11px] text-stone-600 mt-1">Para entrega</p>
        </button>

        {/* Metric 4: Entregadas */}
        <button
          onClick={() => setSelectedFilter('ENTREGADA')}
          className={`text-left p-4 rounded-xl border transition-all ${
            selectedFilter === 'ENTREGADA'
              ? 'bg-stone-100 border-stone-400 ring-2 ring-stone-400/20 shadow-sm'
              : 'bg-white border-stone-200 hover:border-stone-400'
          }`}
        >
          <div className="flex items-center justify-between text-stone-600 mb-1">
            <span className="text-xs font-medium">Entregadas</span>
            <Truck className="w-4 h-4 text-stone-600" />
          </div>
          <div className="text-2xl font-bold text-stone-900 tabular-nums">
            {summary.deliveredCount}
          </div>
          <p className="text-[11px] text-stone-600 mt-1">Completadas</p>
        </button>

        {/* Metric 5: Total Pendiente de Pago (Cartera por cobrar) */}
        <div className="p-4 rounded-xl border border-red-200 bg-red-50/60 col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between text-red-900 mb-1">
            <span className="text-xs font-bold uppercase tracking-tight">Saldo Pendiente</span>
            <DollarSign className="w-4 h-4 text-red-700" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold text-red-700 tabular-nums truncate">
            {formatCOPSimple(summary.totalPendingBalance)}
          </div>
          <p className="text-[11px] text-red-800 mt-1 font-medium">Por cobrar a clientes</p>
        </div>

        {/* Metric 6: Recaudado Total */}
        <div className="p-4 rounded-xl border border-stone-200 bg-stone-50 col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between text-stone-700 mb-1">
            <span className="text-xs font-medium">Recaudado Total</span>
            <TrendingUp className="w-4 h-4 text-amber-700" />
          </div>
          <div className="text-xl sm:text-2xl font-bold text-stone-900 tabular-nums truncate">
            {formatCOPSimple(summary.totalRevenueCollected)}
          </div>
          <p className="text-[11px] text-stone-600 mt-1">
            Hoy: <span className="font-semibold text-stone-900 tabular-nums">{formatCOPSimple(summary.todayRevenue)}</span>
          </p>
        </div>

      </div>

      {/* Interactive Filter Tabs and Search Bar */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-stone-200 shadow-sm space-y-4">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          
          {/* Segmented Filter Controls */}
          <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-xl overflow-x-auto scroll-touch">
            <button
              onClick={() => setSelectedFilter('ALL')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                selectedFilter === 'ALL'
                  ? 'bg-white text-stone-900 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Todas ({orders.length})
            </button>
            <button
              onClick={() => setSelectedFilter('RECIBIDA')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                selectedFilter === 'RECIBIDA'
                  ? 'bg-amber-600 text-stone-950 shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Recibidas ({summary.receivedCount})
            </button>
            <button
              onClick={() => setSelectedFilter('EN PROCESO')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                selectedFilter === 'EN PROCESO'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              En Proceso ({summary.inProcessCount})
            </button>
            <button
              onClick={() => setSelectedFilter('LISTA PARA ENTREGAR')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                selectedFilter === 'LISTA PARA ENTREGAR'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Listas ({summary.readyCount})
            </button>
            <button
              onClick={() => setSelectedFilter('ENTREGADA')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                selectedFilter === 'ENTREGADA'
                  ? 'bg-stone-800 text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Entregadas ({summary.deliveredCount})
            </button>
          </div>

          {/* Inline Quick Search Field */}
          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar por orden, cliente, cel..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white text-stone-900 placeholder-stone-400"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 text-xs font-bold"
              >
                ✕
              </button>
            )}
          </div>

        </div>

        {/* Orders Feed / Cards */}
        {filteredOrders.length === 0 ? (
          <div className="text-center py-12 px-4 border border-dashed border-stone-300 rounded-xl bg-stone-50/50">
            <Inbox className="w-10 h-10 text-stone-300 mx-auto mb-2" />
            <h3 className="text-sm font-semibold text-stone-800">No se encontraron órdenes</h3>
            <p className="text-xs text-stone-600 mt-1 max-w-sm mx-auto">
              {searchQuery
                ? 'No hay reparaciones que coincidan con la búsqueda. Intente con otro término o número de orden.'
                : 'No hay reparaciones en esta categoría actualmente.'}
            </p>
            <button
              onClick={onOpenNewOrder}
              className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 bg-amber-600 text-stone-950 font-bold rounded-lg text-xs hover:bg-amber-500 transition-colors"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Registrar Calzado</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3.5">
            {filteredOrders.map((order) => {
              const statusMeta = getOrderStatusMeta(order.status);
              const hasDebt = order.balanceAmount > 0;

              return (
                <div
                  key={order.id}
                  onClick={() => onOpenOrder(order)}
                  className="group cursor-pointer bg-white border border-stone-200 hover:border-amber-400 hover:shadow-md transition-all rounded-xl p-4 flex flex-col justify-between"
                >
                  <div>
                    {/* Top Row: Order ID + Status Badge */}
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-extrabold text-stone-900 tracking-tight font-mono">
                          {order.id}
                        </span>
                        <span className="text-xs text-stone-600 font-medium">
                          {getShoeTypeLabel(order.shoeType)}
                        </span>
                      </div>
                      
                      <span className={`px-2 py-0.5 text-xs font-bold rounded-md border ${statusMeta.badgeBg} ${statusMeta.badgeText} ${statusMeta.borderColor}`}>
                        {statusMeta.label}
                      </span>
                    </div>

                    {/* Client & Phone */}
                    <div className="space-y-1 mb-3">
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-stone-900">
                        <User className="w-3.5 h-3.5 text-stone-600 shrink-0" />
                        <span className="truncate">{order.clientName}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-xs text-stone-600">
                        <Phone className="w-3.5 h-3.5 text-stone-600 shrink-0" />
                        <span>{order.clientPhone}</span>
                      </div>
                    </div>

                    {/* Work description */}
                    <p className="text-xs text-stone-600 line-clamp-2 mb-3 bg-stone-50 p-2 rounded-lg border border-stone-100">
                      {order.description}
                    </p>

                    {/* Physical location & Estimated delivery */}
                    <div className="flex items-center justify-between text-[11px] text-stone-600 mb-3 pt-1 border-t border-stone-100">
                      <div className="flex items-center gap-1 font-medium text-amber-900 bg-amber-50 px-2 py-0.5 rounded">
                        <MapPin className="w-3 h-3 text-amber-700" />
                        <span>{order.lockerLocation}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-stone-600" />
                        <span>Entrega: {formatDate(order.estimatedDeliveryDate)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Financial Footer */}
                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-stone-600 uppercase font-medium block">Total</span>
                      <span className="text-xs font-bold text-stone-900 tabular-nums">
                        {formatCOP(order.totalAmount)}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-stone-600 uppercase font-medium block">
                        {hasDebt ? 'Saldo por pagar' : 'Estado de pago'}
                      </span>
                      {hasDebt ? (
                        <span className="text-xs font-extrabold text-red-600 tabular-nums">
                          {formatCOP(order.balanceAmount)}
                        </span>
                      ) : (
                        <span className="text-xs font-semibold text-emerald-700">
                          Totalmente pagado ✓
                        </span>
                      )}
                    </div>
                  </div>

                </div>
              );
            })}
          </div>
        )}

      </div>

    </div>
  );
};

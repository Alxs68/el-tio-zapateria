import React, { useState } from 'react';
import { RepairOrder, Client } from '../types';
import { formatCOP, formatDate, getOrderStatusMeta, getShoeTypeLabel } from '../utils/formatters';
import { Search, X, Package, User, ChevronRight } from 'lucide-react';

interface QuickSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  orders: RepairOrder[];
  clients: Client[];
  onSelectOrder: (order: RepairOrder) => void;
  onSelectClient: (client: Client) => void;
}

export const QuickSearchModal: React.FC<QuickSearchModalProps> = ({
  isOpen,
  onClose,
  orders,
  clients,
  onSelectOrder,
  onSelectClient,
}) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const clean = query.trim().toLowerCase();

  const matchedOrders = clean
    ? orders.filter(
        (o) =>
          o.id.toLowerCase().includes(clean) ||
          o.clientName.toLowerCase().includes(clean) ||
          o.clientPhone.includes(clean) ||
          o.lockerLocation.toLowerCase().includes(clean)
      )
    : orders.slice(0, 4);

  const matchedClients = clean
    ? clients.filter(
        (c) =>
          c.fullName.toLowerCase().includes(clean) ||
          c.phone.includes(clean)
      )
    : [];

  return (
    <div className="fixed inset-0 z-60 bg-black/60 backdrop-blur-xs flex items-start justify-center p-4 pt-16 sm:pt-24">
      <div className="bg-white rounded-2xl max-w-xl w-full border border-stone-200 shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
        
        {/* Search Input Bar */}
        <div className="p-4 border-b border-stone-200 flex items-center gap-3">
          <Search className="w-5 h-5 text-stone-400 shrink-0" />
          <input
            autoFocus
            type="text"
            placeholder="Buscar por # de orden (ej. ORD-1001), cliente o teléfono..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full text-xs sm:text-sm font-medium focus:outline-none placeholder-stone-400 text-stone-900"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-stone-400 hover:text-stone-600 text-xs font-bold"
            >
              ✕
            </button>
          )}
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-stone-700 p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results Area */}
        <div className="overflow-y-auto p-4 space-y-4 flex-1 text-xs">
          
          {/* Matched Orders */}
          <div>
            <span className="text-[10px] font-bold text-stone-600 uppercase tracking-wider block mb-2">
              Órdenes de Reparación ({matchedOrders.length})
            </span>
            {matchedOrders.length === 0 ? (
              <p className="text-stone-600 italic py-2">No se encontraron reparaciones con ese término.</p>
            ) : (
              <div className="space-y-1.5">
                {matchedOrders.map((ord) => {
                  const meta = getOrderStatusMeta(ord.status);
                  return (
                    <button
                      key={ord.id}
                      onClick={() => {
                        onSelectOrder(ord);
                        onClose();
                      }}
                      className="w-full text-left p-2.5 rounded-xl hover:bg-stone-50 border border-transparent hover:border-stone-200 transition-colors flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2.5">
                        <Package className="w-4 h-4 text-amber-600 shrink-0" />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-stone-900">{ord.id}</span>
                            <span className="font-semibold text-stone-800">{ord.clientName}</span>
                            <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded ${meta.badgeBg} ${meta.badgeText}`}>
                              {meta.label}
                            </span>
                          </div>
                          <span className="text-[11px] text-stone-600">
                            {getShoeTypeLabel(ord.shoeType)} · {ord.lockerLocation}
                          </span>
                        </div>
                      </div>
                      <div className="text-right shrink-0 font-mono font-bold text-stone-900 tabular-nums">
                        {formatCOP(ord.totalAmount)}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Matched Clients */}
          {matchedClients.length > 0 && (
            <div className="pt-2 border-t border-stone-100">
              <span className="text-[10px] font-bold text-stone-600 uppercase tracking-wider block mb-2">
                Clientes Registrados ({matchedClients.length})
              </span>
              <div className="space-y-1.5">
                {matchedClients.map((cli) => (
                  <button
                    key={cli.id}
                    onClick={() => {
                      onSelectClient(cli);
                      onClose();
                    }}
                    className="w-full text-left p-2.5 rounded-xl hover:bg-stone-50 border border-transparent hover:border-stone-200 transition-colors flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2.5">
                      <User className="w-4 h-4 text-stone-400 shrink-0" />
                      <div>
                        <span className="font-bold text-stone-900 block">{cli.fullName}</span>
                        <span className="text-[11px] text-stone-500">📱 {cli.phone}</span>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-stone-400" />
                  </button>
                ))}
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};

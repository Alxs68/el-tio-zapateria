import React, { useState, useId } from 'react';
import { 
  Client, 
  ServiceCatalogItem, 
  StaffMember, 
  ShoeType, 
  PaymentMethod, 
  RepairOrder,
  OrderServiceItem
} from '../types';
import { 
  formatCOP, 
  validateColombianPhone 
} from '../utils/formatters';
import { 
  X, 
  Plus, 
  Trash2, 
  Camera, 
  ShieldCheck, 
  Calculator, 
  Check, 
  UserPlus,
  AlertCircle
} from 'lucide-react';

interface OrderReceptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  nextOrderCode: string;
  clients: Client[];
  services: ServiceCatalogItem[];
  staffList: StaffMember[];
  activeUser: StaffMember;
  onSaveOrder: (newOrder: Omit<RepairOrder, 'id' | 'createdAt' | 'updatedAt' | 'statusHistory'>) => void;
  onQuickCreateClient: (client: Omit<Client, 'id' | 'createdAt' | 'repairCount'>) => Client;
}

const SHOE_TYPES: { id: ShoeType; label: string }[] = [
  { id: 'zapatos_formales', label: 'Zapatos Formales / Oxford' },
  { id: 'tenis_deportivos', label: 'Zapatillas / Tenis' },
  { id: 'botas_cuero', label: 'Botas de Cuero / Dotación' },
  { id: 'tacones', label: 'Tacones / Dama' },
  { id: 'sandalias', label: 'Sandalias / Chanclas' },
  { id: 'mocasines', label: 'Mocasines / Náuticos' },
  { id: 'botines', label: 'Botines / Chelsea' },
  { id: 'otro', label: 'Otro Tipo de Calzado' },
];

const LOCKER_PRESETS = [
  'Casillero A-01',
  'Casillero A-02',
  'Casillero A-03',
  'Casillero A-04',
  'Casillero B-01',
  'Casillero B-02',
  'Casillero B-05',
  'Casillero C-01 (Mostrador)',
  'Estante Principal #3',
  'Banco de Secado #1',
];

export const OrderReceptionModal: React.FC<OrderReceptionModalProps> = ({
  isOpen,
  onClose,
  nextOrderCode,
  clients,
  services,
  staffList,
  activeUser,
  onSaveOrder,
  onQuickCreateClient,
}) => {
  const fileInputId = useId();
  // Form State
  const [selectedClientId, setSelectedClientId] = useState<string>(clients[0]?.id || '');
  const [isCreatingNewClient, setIsCreatingNewClient] = useState(false);
  const [newClientName, setNewClientName] = useState('');
  const [newClientPhone, setNewClientPhone] = useState('');
  const [newClientNotes, setNewClientNotes] = useState('');

  const [receivedDate, setReceivedDate] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });
  
  const [estimatedDeliveryDate, setEstimatedDeliveryDate] = useState<string>(() => {
    const target = new Date();
    target.setDate(target.getDate() + 3); // 3 days default
    return target.toISOString().split('T')[0];
  });

  const [shoeType, setShoeType] = useState<ShoeType>('zapatos_formales');
  const [description, setDescription] = useState('');
  
  // Selected Services with editable prices
  const [selectedServices, setSelectedServices] = useState<OrderServiceItem[]>([
    {
      serviceId: services[0]?.id || 'srv-1',
      name: services[0]?.name || 'Servicio de Reparación',
      price: services[0]?.basePrice || 20000,
    },
  ]);

  const [initialDeposit, setInitialDeposit] = useState<number>(10000);
  const [depositPaymentMethod, setDepositPaymentMethod] = useState<PaymentMethod>('EFECTIVO');
  const [paymentReference, setPaymentReference] = useState('');
  const [lockerLocation, setLockerLocation] = useState(LOCKER_PRESETS[0]);
  const [assignedStaffId, setAssignedStaffId] = useState<string>(staffList[1]?.id || staffList[0]?.id || '');
  const [observations, setObservations] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [dataPrivacyConsent, setDataPrivacyConsent] = useState(true);

  // Validation error state
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  // Live Calculations
  const totalAmount = selectedServices.reduce((sum, item) => sum + (Number(item.price) || 0), 0);
  const balanceAmount = Math.max(0, totalAmount - initialDeposit);

  // Handle adding service from catalog
  const handleAddService = (serviceId: string) => {
    const found = services.find((s) => s.id === serviceId);
    if (!found) return;
    setSelectedServices([
      ...selectedServices,
      {
        serviceId: found.id,
        name: found.name,
        price: found.basePrice,
      },
    ]);
  };

  const handleUpdateServicePrice = (index: number, newPrice: number) => {
    const updated = [...selectedServices];
    updated[index].price = Math.max(0, newPrice);
    setSelectedServices(updated);
  };

  const handleRemoveService = (index: number) => {
    if (selectedServices.length <= 1) {
      setErrorMessage('La orden debe contener al menos un servicio.');
      return;
    }
    const updated = selectedServices.filter((_, i) => i !== index);
    setSelectedServices(updated);
  };

  // Photo Capture / File Selection
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const base64 = uploadEvent.target?.result as string;
        if (base64) {
          setPhotos((prev) => [...prev, base64].slice(0, 4)); // Max 4 photos
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleRemovePhoto = (index: number) => {
    setPhotos(photos.filter((_, i) => i !== index));
  };

  // Submit Order
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Validate Privacy consent
    if (!dataPrivacyConsent) {
      setErrorMessage('Es obligatoria la autorización del tratamiento de datos personales para continuar.');
      return;
    }

    // Resolve client
    let finalClientId = selectedClientId;
    let finalClientName = '';
    let finalClientPhone = '';

    if (isCreatingNewClient) {
      if (!newClientName.trim()) {
        setErrorMessage('El nombre completo del nuevo cliente es obligatorio.');
        return;
      }
      const phoneValidation = validateColombianPhone(newClientPhone);
      if (!phoneValidation.isValid) {
        setErrorMessage(phoneValidation.message || 'Teléfono no válido.');
        return;
      }

      const created = onQuickCreateClient({
        fullName: newClientName.trim(),
        phone: newClientPhone.trim(),
        notes: newClientNotes.trim(),
      });
      finalClientId = created.id;
      finalClientName = created.fullName;
      finalClientPhone = created.phone;
    } else {
      const existing = clients.find((c) => c.id === selectedClientId);
      if (!existing) {
        setErrorMessage('Seleccione un cliente válido o registre uno nuevo.');
        return;
      }
      finalClientId = existing.id;
      finalClientName = existing.fullName;
      finalClientPhone = existing.phone;
    }

    // Validate description
    if (!description.trim()) {
      setErrorMessage('Ingrese una descripción clara del trabajo solicitado en el calzado.');
      return;
    }

    // Validate services
    if (selectedServices.length === 0 || totalAmount <= 0) {
      setErrorMessage('Debe incluir al menos un servicio con valor mayor a cero.');
      return;
    }

    // Validate deposit
    if (initialDeposit < 0) {
      setErrorMessage('El abono inicial no puede ser un valor negativo.');
      return;
    }
    if (initialDeposit > totalAmount) {
      setErrorMessage(`El abono ($${initialDeposit.toLocaleString('es-CO')}) no puede exceder el total de la orden ($${totalAmount.toLocaleString('es-CO')}).`);
      return;
    }

    // Find assigned staff
    const assignedStaff = staffList.find((s) => s.id === assignedStaffId) || staffList[0];

    // Build initial payment if deposit > 0
    const initialPayments = initialDeposit > 0 ? [{
      id: `pay-${Date.now()}`,
      date: new Date().toISOString(),
      amount: initialDeposit,
      paymentMethod: depositPaymentMethod,
      reference: paymentReference || undefined,
      registeredBy: activeUser.name,
      notes: 'Abono inicial en recepción de calzado',
    }] : [];

    // Create order payload
    onSaveOrder({
      clientId: finalClientId,
      clientName: finalClientName,
      clientPhone: finalClientPhone,
      receivedDate: new Date(receivedDate).toISOString(),
      estimatedDeliveryDate: new Date(estimatedDeliveryDate).toISOString(),
      shoeType,
      description: description.trim(),
      services: selectedServices,
      totalAmount,
      paidAmount: initialDeposit,
      balanceAmount,
      lockerLocation: lockerLocation.trim() || 'Por asignar',
      assignedStaffId: assignedStaff.id,
      assignedStaffName: assignedStaff.name,
      observations: observations.trim() || undefined,
      photos,
      dataPrivacyAuthorized: true,
      status: 'RECIBIDA',
      payments: initialPayments,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-stone-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="bg-stone-900 text-stone-100 px-5 py-4 flex items-center justify-between border-b border-stone-800 shrink-0">
          <div className="flex items-center gap-3">
            <span className="bg-amber-600 text-stone-950 text-xs font-mono font-extrabold px-2 py-0.5 rounded">
              {nextOrderCode}
            </span>
            <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
              Recepción de Calzado & Nueva Orden
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-white p-1 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1 text-xs sm:text-sm">
          
          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Section 1: Cliente */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="font-bold text-stone-900 text-xs uppercase tracking-wide">
                1. Datos del Cliente *
              </label>
              <button
                type="button"
                onClick={() => setIsCreatingNewClient(!isCreatingNewClient)}
                className="text-xs text-amber-700 hover:text-amber-800 font-semibold flex items-center gap-1"
              >
                {isCreatingNewClient ? 'Seleccionar existente' : '+ Registrar nuevo cliente'}
              </button>
            </div>

            {isCreatingNewClient ? (
              <div className="p-4 bg-amber-50/50 border border-amber-200 rounded-xl space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Nombre Completo *</label>
                    <input
                      type="text"
                      placeholder="Ej. Rodrigo Mendoza"
                      value={newClientName}
                      onChange={(e) => setNewClientName(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Celular (10 dígitos) *</label>
                    <input
                      type="tel"
                      placeholder="Ej. 310 123 4567"
                      value={newClientPhone}
                      onChange={(e) => setNewClientPhone(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">Observaciones del Cliente</label>
                  <input
                    type="text"
                    placeholder="Preferencias o detalles adicionales..."
                    value={newClientNotes}
                    onChange={(e) => setNewClientNotes(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  />
                </div>
              </div>
            ) : (
              <div>
                <select
                  value={selectedClientId}
                  onChange={(e) => setSelectedClientId(e.target.value)}
                  className="w-full px-3 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs sm:text-sm font-medium focus:ring-2 focus:ring-amber-500 focus:outline-none"
                >
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.fullName} — 📱 {c.phone} {c.notes ? `(${c.notes})` : ''}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {/* Section 2: Tipo de Calzado y Fechas */}
          <div className="space-y-3">
            <label className="font-bold text-stone-900 text-xs uppercase tracking-wide">
              2. Calzado & Tiempos *
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs text-stone-600 mb-1">Tipo de Calzado</label>
                <select
                  value={shoeType}
                  onChange={(e) => setShoeType(e.target.value as ShoeType)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-amber-500 focus:outline-none"
                >
                  {SHOE_TYPES.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs text-stone-600 mb-1">Fecha de Recepción</label>
                <input
                  type="date"
                  value={receivedDate}
                  onChange={(e) => setReceivedDate(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs text-stone-600 mb-1">Promesa de Entrega</label>
                <input
                  type="date"
                  value={estimatedDeliveryDate}
                  onChange={(e) => setEstimatedDeliveryDate(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-amber-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Descripción del Trabajo Solicitado *
              </label>
              <textarea
                rows={2}
                placeholder="Ej. Cambio de tapas traseras, desmonte de mediasuelas de cuero desgastadas y brillo especial tono marrón..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Section 3: Servicios del Catálogo & Precios */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="font-bold text-stone-900 text-xs uppercase tracking-wide">
                3. Servicios & Tarifas (COP) *
              </label>
              <div className="flex items-center gap-2">
                <span className="text-xs text-stone-500">Agregar del catálogo:</span>
                <select
                  onChange={(e) => {
                    if (e.target.value) {
                      handleAddService(e.target.value);
                      e.target.value = '';
                    }
                  }}
                  className="text-xs bg-stone-100 border border-stone-300 rounded-lg px-2 py-1 focus:outline-none cursor-pointer"
                  defaultValue=""
                >
                  <option value="" disabled>+ Seleccionar servicio...</option>
                  {services.filter((s) => s.active).map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({formatCOP(s.basePrice)})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Services Table */}
            <div className="border border-stone-200 rounded-xl overflow-hidden bg-stone-50/50">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-100 border-b border-stone-200 text-stone-600 font-semibold">
                  <tr>
                    <th className="py-2.5 px-3">Servicio</th>
                    <th className="py-2.5 px-3 text-right w-36">Precio (COP)</th>
                    <th className="py-2.5 px-2 text-center w-12">Acción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200 bg-white">
                  {selectedServices.map((item, idx) => (
                    <tr key={`${item.serviceId}-${idx}`}>
                      <td className="py-2.5 px-3">
                        <span className="font-medium text-stone-900 block">{item.name}</span>
                      </td>
                      <td className="py-2 px-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <span className="text-stone-600 font-semibold">$</span>
                          <input
                            type="number"
                            min="0"
                            step="1000"
                            value={item.price}
                            onChange={(e) => handleUpdateServicePrice(idx, Number(e.target.value))}
                            className="w-24 text-right px-2 py-1 bg-stone-50 border border-stone-300 rounded text-xs font-bold text-stone-900 tabular-nums focus:outline-none focus:ring-1 focus:ring-amber-500"
                          />
                        </div>
                      </td>
                      <td className="py-2 px-2 text-center">
                        <button
                          type="button"
                          onClick={() => handleRemoveService(idx)}
                          className="text-stone-400 hover:text-red-600 p-1 rounded transition-colors"
                          title="Eliminar servicio"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Financial Calculator: Total, Abono, Saldo */}
            <div className="p-4 bg-stone-100 rounded-xl border border-stone-200 space-y-3">
              <div className="flex items-center justify-between text-xs sm:text-sm font-bold text-stone-900">
                <span>Total de la Reparación:</span>
                <span className="text-base text-stone-950 tabular-nums">{formatCOP(totalAmount)}</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-stone-200">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Abono Inicial (COP)
                  </label>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs text-stone-500 font-bold">$</span>
                    <input
                      type="number"
                      min="0"
                      max={totalAmount}
                      step="1000"
                      value={initialDeposit}
                      onChange={(e) => setInitialDeposit(Math.min(totalAmount, Math.max(0, Number(e.target.value))))}
                      className="w-full px-3 py-1.5 bg-white border border-stone-300 rounded-lg text-xs font-bold text-stone-900 tabular-nums focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                  {/* Quick percentage buttons */}
                  <div className="flex items-center gap-1.5 mt-1.5">
                    <button
                      type="button"
                      onClick={() => setInitialDeposit(0)}
                      className="px-2 py-0.5 text-[10px] bg-stone-200 hover:bg-stone-300 text-stone-700 rounded font-medium"
                    >
                      Sin abono ($0)
                    </button>
                    <button
                      type="button"
                      onClick={() => setInitialDeposit(Math.round(totalAmount * 0.5))}
                      className="px-2 py-0.5 text-[10px] bg-stone-200 hover:bg-stone-300 text-stone-700 rounded font-medium"
                    >
                      50% ({formatCOP(Math.round(totalAmount * 0.5))})
                    </button>
                    <button
                      type="button"
                      onClick={() => setInitialDeposit(totalAmount)}
                      className="px-2 py-0.5 text-[10px] bg-stone-200 hover:bg-stone-300 text-stone-700 rounded font-medium"
                    >
                      Total (100%)
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Método de Pago del Abono
                  </label>
                  <select
                    value={depositPaymentMethod}
                    onChange={(e) => setDepositPaymentMethod(e.target.value as PaymentMethod)}
                    className="w-full px-3 py-1.5 bg-white border border-stone-300 rounded-lg text-xs font-medium focus:outline-none focus:ring-2 focus:ring-amber-500"
                  >
                    <option value="EFECTIVO">Efectivo en caja</option>
                    <option value="NEQUI">Nequi</option>
                    <option value="DAVIPLATA">Daviplata</option>
                    <option value="TRANSFERENCIA">Transferencia Bancolombia / Otro</option>
                    <option value="TARJETA">Tarjeta Débito/Crédito</option>
                  </select>

                  {depositPaymentMethod !== 'EFECTIVO' && (
                    <input
                      type="text"
                      placeholder="Ref. o Comprobante (opcional)"
                      value={paymentReference}
                      onChange={(e) => setPaymentReference(e.target.value)}
                      className="w-full mt-1.5 px-3 py-1 bg-white border border-stone-300 rounded text-[11px] text-stone-800"
                    />
                  )}
                </div>
              </div>

              {/* Saldo Resultante Highlight */}
              <div className="flex items-center justify-between p-2.5 bg-white rounded-lg border border-stone-300">
                <span className="text-xs font-bold text-stone-700">Saldo Pendiente al Retiro:</span>
                <span className={`text-sm font-extrabold tabular-nums ${balanceAmount > 0 ? 'text-red-600' : 'text-emerald-700'}`}>
                  {balanceAmount > 0 ? formatCOP(balanceAmount) : '$ 0 COP (Paz y Salvo)'}
                </span>
              </div>
            </div>
          </div>

          {/* Section 4: Ubicación física, Operario & Observaciones */}
          <div className="space-y-3">
            <label className="font-bold text-stone-900 text-xs uppercase tracking-wide">
              4. Asignación en Taller *
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-stone-600 mb-1">Casillero o Estante Físico *</label>
                <div className="space-y-1.5">
                  <input
                    type="text"
                    value={lockerLocation}
                    onChange={(e) => setLockerLocation(e.target.value)}
                    placeholder="Ej. Casillero A-04"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-bold text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                  <div className="flex flex-wrap gap-1">
                    {LOCKER_PRESETS.slice(0, 5).map((preset) => (
                      <button
                        type="button"
                        key={preset}
                        onClick={() => setLockerLocation(preset)}
                        className={`text-[10px] px-2 py-0.5 rounded border transition-colors ${
                          lockerLocation === preset
                            ? 'bg-amber-100 text-amber-900 border-amber-300 font-bold'
                            : 'bg-stone-100 text-stone-600 border-stone-200 hover:bg-stone-200'
                        }`}
                      >
                        {preset.split(' ')[1] || preset}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs text-stone-600 mb-1">Maestro Zapatero Responsable</label>
                <select
                  value={assignedStaffId}
                  onChange={(e) => setAssignedStaffId(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs font-medium focus:outline-none focus:ring-2 focus:ring-amber-500"
                >
                  {staffList.filter((s) => s.active).map((stf) => (
                    <option key={stf.id} value={stf.id}>
                      {stf.name} ({stf.specialty || stf.role})
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-stone-600 mt-1">
                  Registrado por: <strong className="text-stone-800">{activeUser.name}</strong>
                </p>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Observaciones del Estado de Recepción
              </label>
              <input
                type="text"
                placeholder="Ej. Cuero descolorido en puntera, plantilla derecha rota, rayón preexistente..."
                value={observations}
                onChange={(e) => setObservations(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-lg text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Section 5: Fotografías del Calzado */}
          <div className="space-y-3">
            <label className="font-bold text-stone-900 text-xs uppercase tracking-wide">
              5. Fotografías del Calzado
            </label>
            <p className="text-xs text-stone-600">
              Captura o adjunta fotos del calzado como constancia de su estado físico inicial.
            </p>

            <div className="flex flex-wrap items-center gap-3">
              <label
                htmlFor={fileInputId}
                className="cursor-pointer flex items-center gap-2 px-3 py-2 bg-stone-100 hover:bg-stone-200 border border-stone-300 rounded-xl text-xs font-semibold text-stone-800 transition-colors"
              >
                <Camera className="w-4 h-4 text-amber-600" />
                <span>Tomar / Seleccionar Foto</span>
              </label>
              <input
                id={fileInputId}
                type="file"
                accept="image/*"
                capture="environment"
                multiple
                onChange={handlePhotoUpload}
                className="hidden"
              />

              {photos.length > 0 && (
                <span className="text-xs text-stone-500">
                  {photos.length} {photos.length === 1 ? 'foto adjunta' : 'fotos adjuntas'} (máx 4)
                </span>
              )}
            </div>

            {/* Photo Previews */}
            {photos.length > 0 && (
              <div className="flex flex-wrap gap-2 pt-2">
                {photos.map((photo, index) => (
                  <div key={index} className="relative w-20 h-20 rounded-lg overflow-hidden border border-stone-300 group">
                    <img
                      src={photo}
                      alt={`Foto calzado ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => handleRemovePhoto(index)}
                      className="absolute top-1 right-1 p-1 bg-black/70 hover:bg-red-600 text-white rounded-full transition-colors"
                      title="Eliminar foto"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Section 6: Habeas Data Legal Consent */}
          <div className="p-3.5 bg-stone-100/80 rounded-xl border border-stone-200 space-y-2">
            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={dataPrivacyConsent}
                onChange={(e) => setDataPrivacyConsent(e.target.checked)}
                className="mt-0.5 w-4 h-4 text-amber-600 rounded border-stone-300 focus:ring-amber-500"
              />
              <span className="text-xs text-stone-700 leading-snug">
                <strong>Autorización de Tratamiento de Datos Personales (Ley 1581 de 2012):</strong> El cliente autoriza expresamente a <em>Zapatería El Tío</em> para recolectar su nombre y número telefónico con el fin exclusivo de contactarlo sobre el estado de su calzado y garantías.
              </span>
            </label>
          </div>

          {/* Action Buttons */}
          <div className="pt-4 border-t border-stone-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-stone-300 rounded-xl text-xs font-semibold text-stone-700 hover:bg-stone-100 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold rounded-xl text-xs sm:text-sm flex items-center gap-1.5 shadow-md transition-transform active:scale-95"
            >
              <Check className="w-4 h-4 text-stone-950" />
              <span>Guardar Orden ({nextOrderCode})</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};

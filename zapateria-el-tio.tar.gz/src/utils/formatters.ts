import { OrderStatus, ShoeType, RepairOrder } from '../types';

/**
 * Formats a number to Colombian Pesos (COP).
 * Example: 25000 -> "$ 25.000 COP"
 */
export function formatCOP(amount: number | null | undefined): string {
  if (amount === null || amount === undefined || isNaN(amount)) {
    return '$ 0 COP';
  }
  const formatted = new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
  
  return `${formatted} COP`;
}

/**
 * Compact format for badges or small cards: "$ 25.000"
 */
export function formatCOPSimple(amount: number | null | undefined): string {
  if (amount === null || amount === undefined || isNaN(amount)) {
    return '$ 0';
  }
  return new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

/**
 * Formats an ISO date into Spanish conversational format
 * Example: "27 de oct, 2026"
 */
export function formatDate(dateString: string | null | undefined): string {
  if (!dateString) return '—';
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return '—';
    return d.toLocaleDateString('es-CO', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return dateString;
  }
}

/**
 * Formats date and time
 * Example: "27 oct 2026, 03:45 pm"
 */
export function formatDateTime(dateString: string | null | undefined): string {
  if (!dateString) return '—';
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return '—';
    return d.toLocaleString('es-CO', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  } catch {
    return dateString;
  }
}

/**
 * Validates a Colombian phone number (cellular standard: 10 digits starting with 3)
 */
export function validateColombianPhone(phone: string): { isValid: boolean; message?: string } {
  const digits = phone.replace(/\D/g, '');
  if (!digits) {
    return { isValid: false, message: 'El número de teléfono es obligatorio.' };
  }
  if (digits.length !== 10) {
    return { isValid: false, message: 'El celular debe tener 10 dígitos (ej. 300 123 4567).' };
  }
  if (!digits.startsWith('3')) {
    return { isValid: false, message: 'En Colombia los celulares inician con el número 3.' };
  }
  return { isValid: true };
}

/**
 * Cleans phone number to international WhatsApp format for Colombia (+57)
 */
export function cleanPhoneForWhatsApp(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  if (digits.length === 10) {
    return `57${digits}`;
  }
  if (digits.startsWith('57') && digits.length === 12) {
    return digits;
  }
  return digits;
}

export function getShoeTypeLabel(type: ShoeType): string {
  const map: Record<ShoeType, string> = {
    zapatos_formales: 'Zapatos Formales',
    tenis_deportivos: 'Zapatillas / Tenis',
    botas_cuero: 'Botas de Cuero / Trabajo',
    tacones: 'Tacones / Zapatillas de Dama',
    sandalias: 'Sandalias / Chanclas',
    mocasines: 'Mocasines / Casual',
    botines: 'Botines / Chelsea',
    otro: 'Otro Tipo de Calzado',
  };
  return map[type] || 'Calzado';
}

export interface StatusMeta {
  label: string;
  badgeBg: string;
  badgeText: string;
  borderColor: string;
  description: string;
  allowedNextStates: OrderStatus[];
}

export function getOrderStatusMeta(status: OrderStatus): StatusMeta {
  switch (status) {
    case 'RECIBIDA':
      return {
        label: 'Recibida',
        badgeBg: 'bg-amber-100 dark:bg-amber-950/60',
        badgeText: 'text-amber-900 dark:text-amber-300',
        borderColor: 'border-amber-300 dark:border-amber-700',
        description: 'Calzado recibido en taller. Esperando inicio de labores.',
        allowedNextStates: ['EN PROCESO', 'CANCELADA'],
      };
    case 'EN PROCESO':
      return {
        label: 'En Proceso',
        badgeBg: 'bg-blue-100 dark:bg-blue-950/60',
        badgeText: 'text-blue-900 dark:text-blue-300',
        borderColor: 'border-blue-300 dark:border-blue-700',
        description: 'El maestro zapatero se encuentra trabajando en la reparación.',
        allowedNextStates: ['LISTA PARA ENTREGAR', 'CANCELADA'],
      };
    case 'LISTA PARA ENTREGAR':
      return {
        label: 'Lista para Entregar',
        badgeBg: 'bg-emerald-100 dark:bg-emerald-950/60',
        badgeText: 'text-emerald-900 dark:text-emerald-300',
        borderColor: 'border-emerald-300 dark:border-emerald-700',
        description: 'Trabajo terminado y verificado. Disponible para retiro en taller.',
        allowedNextStates: ['ENTREGADA', 'EN PROCESO', 'CANCELADA'],
      };
    case 'ENTREGADA':
      return {
        label: 'Entregada',
        badgeBg: 'bg-stone-200 dark:bg-stone-800',
        badgeText: 'text-stone-900 dark:text-stone-200',
        borderColor: 'border-stone-400 dark:border-stone-600',
        description: 'Calzado entregado satisfactoriamente al cliente.',
        allowedNextStates: [],
      };
    case 'CANCELADA':
      return {
        label: 'Cancelada',
        badgeBg: 'bg-red-100 dark:bg-red-950/60',
        badgeText: 'text-red-900 dark:text-red-300',
        borderColor: 'border-red-300 dark:border-red-700',
        description: 'Orden anulada o rechazada.',
        allowedNextStates: ['RECIBIDA'], // Allow reactivation only if mistake
      };
  }
}

/**
 * Checks if a transition between two states is permitted by business rules
 */
export function canTransitionStatus(
  current: OrderStatus,
  target: OrderStatus,
  balance: number,
  isAdmin: boolean,
  adminAuthorized: boolean = false
): { allowed: boolean; reason?: string } {
  if (current === target) return { allowed: true };

  // Terminal state protection
  if (current === 'ENTREGADA' && !isAdmin) {
    return {
      allowed: false,
      reason: 'Una orden ya entregada no puede modificarse de estado salvo por el Administrador.',
    };
  }

  // Coherent path validation
  const meta = getOrderStatusMeta(current);
  if (!meta.allowedNextStates.includes(target) && !isAdmin) {
    return {
      allowed: false,
      reason: `No se permite cambiar directamente de "${current}" a "${target}". Siga el flujo del taller.`,
    };
  }

  // Delivery balance rule: Mandatory constraint from requirement 5
  if (target === 'ENTREGADA') {
    if (balance > 0) {
      if (!adminAuthorized && !isAdmin) {
        return {
          allowed: false,
          reason: `No se puede entregar calzado con saldo pendiente (${formatCOP(balance)}). Se requiere el pago total o la autorización expresa de un Administrador.`,
        };
      }
    }
  }

  return { allowed: true };
}

/**
 * Generates WhatsApp notification text and URL
 */
export function generateWhatsAppNotification(
  order: RepairOrder,
  notificationType: 'RECEPCION' | 'LISTA' | 'ENTREGA'
): { message: string; url: string } {
  const shopName = 'Zapatería El Tío';
  const cleanPhone = cleanPhoneForWhatsApp(order.clientPhone);
  
  let message = '';

  if (notificationType === 'RECEPCION') {
    message = `Hola ${order.clientName}, ¡gracias por confiar en ${shopName}! 👞✨\n\n` +
      `Hemos registrado su orden *#${order.id}* con éxito.\n` +
      `• *Calzado:* ${getShoeTypeLabel(order.shoeType)}\n` +
      `• *Trabajo:* ${order.description}\n` +
      `• *Total:* ${formatCOP(order.totalAmount)}\n` +
      `• *Abono inicial:* ${formatCOP(order.paidAmount)}\n` +
      `• *Saldo pendiente:* ${formatCOP(order.balanceAmount)}\n` +
      `• *Ubicación en taller:* ${order.lockerLocation}\n` +
      `• *Fecha estimada:* ${formatDate(order.estimatedDeliveryDate)}\n\n` +
      `Le avisaremos de inmediato cuando su calzado esté listo para entrega. ¡Feliz día!`;
  } else if (notificationType === 'LISTA') {
    message = `Hola ${order.clientName}, le informamos desde *${shopName}* que su reparación *#${order.id}* ya está *LISTA PARA ENTREGAR* 🎉👞.\n\n` +
      `• *Calzado:* ${getShoeTypeLabel(order.shoeType)}\n` +
      `• *Saldo a cancelar:* ${formatCOP(order.balanceAmount)}\n` +
      `• *Ubicación de retiro:* ${order.lockerLocation}\n\n` +
      `Puede pasar por el taller en nuestro horario habitual. Recuerde presentar su número de orden. ¡Lo esperamos!`;
  } else {
    message = `Hola ${order.clientName}, desde *${shopName}* confirmamos la entrega de su orden *#${order.id}*. ✅\n\n` +
      `Esperamos que el trabajo en sus ${getShoeTypeLabel(order.shoeType).toLowerCase()} sea de su total agrado.\n` +
      `Cualquier duda o ajuste, cuenta con nuestra garantía de servicio artesanal.\n` +
      `¡Muchas gracias por su preferencia!`;
  }

  const encoded = encodeURIComponent(message);
  const url = `https://wa.me/${cleanPhone}?text=${encoded}`;

  return { message, url };
}

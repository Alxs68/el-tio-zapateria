import {
  RepairOrder,
  Client,
  ServiceCatalogItem,
  StaffMember,
  FinancialSummary,
  OrderStatus,
  PaymentMethod,
  OrderPayment,
} from '../types';

const STORAGE_KEYS = {
  ORDERS: 'zapateria_eltio_orders_v1',
  CLIENTS: 'zapateria_eltio_clients_v1',
  SERVICES: 'zapateria_eltio_services_v1',
  STAFF: 'zapateria_eltio_staff_v1',
  ACTIVE_USER: 'zapateria_eltio_active_user_v1',
  NEXT_ORDER_NUM: 'zapateria_eltio_next_order_v1',
};

// Initial Seed Data for Zapatería El Tío
const INITIAL_SERVICES: ServiceCatalogItem[] = [
  {
    id: 'srv-1',
    name: 'Cambio de Tapas para Tacón',
    description: 'Reemplazo de tapas de poliuretano antideslizante de alta durabilidad.',
    category: 'suelas',
    basePrice: 15000,
    estimatedHours: 2,
    active: true,
  },
  {
    id: 'srv-2',
    name: 'Cambio de Suela Completa (Cuero o Crepé)',
    description: 'Desmonte total de suela vieja, nivelado de planta y postura de suela nueva importada.',
    category: 'suelas',
    basePrice: 65000,
    estimatedHours: 24,
    active: true,
  },
  {
    id: 'srv-3',
    name: 'Cosido y Pegado Perimetral Reforzado',
    description: 'Pegado con cemento de contacto vulcanizado más costura con hilo encerado #3.',
    category: 'costura',
    basePrice: 22000,
    estimatedHours: 4,
    active: true,
  },
  {
    id: 'srv-4',
    name: 'Tintura y Lustre Artesanal a la Crema',
    description: 'Limpieza profunda de poros, tintura al tono original y acabado con cera carnauba.',
    category: 'lustre',
    basePrice: 30000,
    estimatedHours: 6,
    active: true,
  },
  {
    id: 'srv-5',
    name: 'Cambio de Cremallera / Cierre para Botas',
    description: 'Instalación de cremallera metálica YKK para botas de caña alta o botines.',
    category: 'accesorios',
    basePrice: 28000,
    estimatedHours: 5,
    active: true,
  },
  {
    id: 'srv-6',
    name: 'Plantillas Ortopédicas en Badana Natural',
    description: 'Confección a la medida con soporte de arco metatarsiano y badana suave transpirable.',
    category: 'ortopedia',
    basePrice: 25000,
    estimatedHours: 3,
    active: true,
  },
  {
    id: 'srv-7',
    name: 'Alargue o Ensanche en Horma Calefactada',
    description: 'Proceso mecánico progresivo de 48 horas para ampliar empeine o longitud.',
    category: 'general',
    basePrice: 18000,
    estimatedHours: 48,
    active: true,
  },
  {
    id: 'srv-8',
    name: 'Refuerzo de Talonera y Puntera Metálica',
    description: 'Reconstrucción de contrafuerte interior en cuero rígido de res.',
    category: 'general',
    basePrice: 20000,
    estimatedHours: 4,
    active: true,
  },
];

const INITIAL_STAFF: StaffMember[] = [
  {
    id: 'stf-1',
    name: 'Alexis Oliveros (Don Tío)',
    role: 'ADMIN',
    specialty: 'Maestro Zapatero & Gerencia',
    phone: '3104567890',
    active: true,
  },
  {
    id: 'stf-2',
    name: 'Carlos Mario Restrepo',
    role: 'OPERARIO',
    specialty: 'Especialista en Suelas y Clavado',
    phone: '3145678901',
    active: true,
  },
  {
    id: 'stf-3',
    name: 'Marta Lucía Henao',
    role: 'OPERARIO',
    specialty: 'Costura Fina, Cremalleras y Tintura',
    phone: '3209876543',
    active: true,
  },
];

const INITIAL_CLIENTS: Client[] = [
  {
    id: 'cli-1',
    fullName: 'María Camila Gómez Torres',
    phone: '3007654321',
    notes: 'Cliente preferencial. Le gusta el brillo espejo en sus zapatos formales.',
    createdAt: '2026-10-10T10:00:00.000Z',
    repairCount: 3,
  },
  {
    id: 'cli-2',
    fullName: 'Javier Enrique Morales',
    phone: '3128901234',
    notes: 'Usa botas de seguridad pesadas para trabajo de campo.',
    createdAt: '2026-10-15T14:30:00.000Z',
    repairCount: 2,
  },
  {
    id: 'cli-3',
    fullName: 'Patricia Elena Salazar',
    phone: '3156782345',
    notes: 'Requiere siempre plantillas suaves de badana.',
    createdAt: '2026-10-20T09:15:00.000Z',
    repairCount: 1,
  },
  {
    id: 'cli-4',
    fullName: 'Andrés Felipe Cardona',
    phone: '3182345678',
    notes: 'Coleccionista de tenis deportivos retro.',
    createdAt: '2026-10-24T16:00:00.000Z',
    repairCount: 1,
  },
];

const INITIAL_ORDERS: RepairOrder[] = [
  {
    id: 'ORD-1001',
    clientId: 'cli-1',
    clientName: 'María Camila Gómez Torres',
    clientPhone: '3007654321',
    receivedDate: '2026-10-25T09:30:00.000Z',
    estimatedDeliveryDate: '2026-10-28T17:00:00.000Z',
    shoeType: 'zapatos_formales',
    description: 'Zapatos Oxford color café. Desgaste en tapas y raspón lateral derecho.',
    services: [
      { serviceId: 'srv-1', name: 'Cambio de Tapas para Tacón', price: 15000 },
      { serviceId: 'srv-4', name: 'Tintura y Lustre Artesanal a la Crema', price: 30000 },
    ],
    totalAmount: 45000,
    paidAmount: 20000,
    balanceAmount: 25000,
    lockerLocation: 'Casillero A-04',
    assignedStaffId: 'stf-2',
    assignedStaffName: 'Carlos Mario Restrepo',
    observations: 'Piel con reseca en punta, hidratar con lanolina antes de lustrar.',
    photos: [],
    dataPrivacyAuthorized: true,
    status: 'EN PROCESO',
    statusHistory: [
      {
        id: 'hist-1',
        toStatus: 'RECIBIDA',
        changedAt: '2026-10-25T09:30:00.000Z',
        changedBy: 'Alexis Oliveros (Don Tío)',
        reason: 'Recepción en mostrador y abono de $ 20.000',
      },
      {
        id: 'hist-2',
        fromStatus: 'RECIBIDA',
        toStatus: 'EN PROCESO',
        changedAt: '2026-10-26T08:15:00.000Z',
        changedBy: 'Carlos Mario Restrepo',
        reason: 'Iniciada preparación de tapas y lijado de tacones',
      },
    ],
    payments: [
      {
        id: 'pay-1',
        date: '2026-10-25T09:30:00.000Z',
        amount: 20000,
        paymentMethod: 'NEQUI',
        reference: 'M09871234',
        registeredBy: 'Alexis Oliveros (Don Tío)',
        notes: 'Abono inicial al recibir calzado',
      },
    ],
    createdAt: '2026-10-25T09:30:00.000Z',
    updatedAt: '2026-10-26T08:15:00.000Z',
  },
  {
    id: 'ORD-1002',
    clientId: 'cli-2',
    clientName: 'Javier Enrique Morales',
    clientPhone: '3128901234',
    receivedDate: '2026-10-26T11:00:00.000Z',
    estimatedDeliveryDate: '2026-10-29T12:00:00.000Z',
    shoeType: 'botas_cuero',
    description: 'Botas de dotación de cuero graso. Suela despegada en puntera y rajadura de costura.',
    services: [
      { serviceId: 'srv-3', name: 'Cosido y Pegado Perimetral Reforzado', price: 22000 },
      { serviceId: 'srv-8', name: 'Refuerzo de Talonera y Puntera Metálica', price: 20000 },
    ],
    totalAmount: 42000,
    paidAmount: 42000,
    balanceAmount: 0,
    lockerLocation: 'Casillero B-12',
    assignedStaffId: 'stf-2',
    assignedStaffName: 'Carlos Mario Restrepo',
    observations: 'Cliente pagó totalidad anticipada con Daviplata.',
    photos: [],
    dataPrivacyAuthorized: true,
    status: 'RECIBIDA',
    statusHistory: [
      {
        id: 'hist-3',
        toStatus: 'RECIBIDA',
        changedAt: '2026-10-26T11:00:00.000Z',
        changedBy: 'Alexis Oliveros (Don Tío)',
        reason: 'Ingreso al taller con pago total cancelado',
      },
    ],
    payments: [
      {
        id: 'pay-2',
        date: '2026-10-26T11:00:00.000Z',
        amount: 42000,
        paymentMethod: 'DAVIPLATA',
        reference: 'D762391',
        registeredBy: 'Alexis Oliveros (Don Tío)',
        notes: 'Pago total por adelantado',
      },
    ],
    createdAt: '2026-10-26T11:00:00.000Z',
    updatedAt: '2026-10-26T11:00:00.000Z',
  },
  {
    id: 'ORD-1003',
    clientId: 'cli-3',
    clientName: 'Patricia Elena Salazar',
    clientPhone: '3156782345',
    receivedDate: '2026-10-23T15:20:00.000Z',
    estimatedDeliveryDate: '2026-10-27T10:00:00.000Z',
    shoeType: 'tacones',
    description: 'Tacones de fiesta color marfil. Se cambió el tacón fino y plantilla interna.',
    services: [
      { serviceId: 'srv-1', name: 'Cambio de Tapas para Tacón', price: 15000 },
      { serviceId: 'srv-6', name: 'Plantillas Ortopédicas en Badana Natural', price: 25000 },
    ],
    totalAmount: 40000,
    paidAmount: 20000,
    balanceAmount: 20000,
    lockerLocation: 'Casillero C-01 (Mostrador)',
    assignedStaffId: 'stf-3',
    assignedStaffName: 'Marta Lucía Henao',
    observations: 'Trabajo terminado, empacado en bolsa protectora con seda.',
    photos: [],
    dataPrivacyAuthorized: true,
    status: 'LISTA PARA ENTREGAR',
    statusHistory: [
      {
        id: 'hist-4',
        toStatus: 'RECIBIDA',
        changedAt: '2026-10-23T15:20:00.000Z',
        changedBy: 'Marta Lucía Henao',
      },
      {
        id: 'hist-5',
        fromStatus: 'RECIBIDA',
        toStatus: 'EN PROCESO',
        changedAt: '2026-10-24T09:00:00.000Z',
        changedBy: 'Marta Lucía Henao',
      },
      {
        id: 'hist-6',
        fromStatus: 'EN PROCESO',
        toStatus: 'LISTA PARA ENTREGAR',
        changedAt: '2026-10-26T17:40:00.000Z',
        changedBy: 'Alexis Oliveros (Don Tío)',
        reason: 'Inspección de calidad aprobada. Calzado listo para retiro.',
      },
    ],
    payments: [
      {
        id: 'pay-3',
        date: '2026-10-23T15:20:00.000Z',
        amount: 20000,
        paymentMethod: 'EFECTIVO',
        registeredBy: 'Marta Lucía Henao',
        notes: 'Abono 50%',
      },
    ],
    createdAt: '2026-10-23T15:20:00.000Z',
    updatedAt: '2026-10-26T17:40:00.000Z',
  },
  {
    id: 'ORD-1004',
    clientId: 'cli-4',
    clientName: 'Andrés Felipe Cardona',
    clientPhone: '3182345678',
    receivedDate: '2026-10-21T10:10:00.000Z',
    estimatedDeliveryDate: '2026-10-24T18:00:00.000Z',
    shoeType: 'tenis_deportivos',
    description: 'Zapatillas retro cuero blanco. Pegado perimetral y cambio de suela completa.',
    services: [
      { serviceId: 'srv-2', name: 'Cambio de Suela Completa (Cuero o Crepé)', price: 65000 },
      { serviceId: 'srv-3', name: 'Cosido y Pegado Perimetral Reforzado', price: 22000 },
    ],
    totalAmount: 87000,
    paidAmount: 87000,
    balanceAmount: 0,
    lockerLocation: 'Entregado',
    assignedStaffId: 'stf-2',
    assignedStaffName: 'Carlos Mario Restrepo',
    observations: 'Entregado en perfectas condiciones.',
    photos: [],
    dataPrivacyAuthorized: true,
    status: 'ENTREGADA',
    statusHistory: [
      {
        id: 'hist-7',
        toStatus: 'RECIBIDA',
        changedAt: '2026-10-21T10:10:00.000Z',
        changedBy: 'Carlos Mario Restrepo',
      },
      {
        id: 'hist-8',
        fromStatus: 'RECIBIDA',
        toStatus: 'EN PROCESO',
        changedAt: '2026-10-22T08:30:00.000Z',
        changedBy: 'Carlos Mario Restrepo',
      },
      {
        id: 'hist-9',
        fromStatus: 'EN PROCESO',
        toStatus: 'LISTA PARA ENTREGAR',
        changedAt: '2026-10-24T14:10:00.000Z',
        changedBy: 'Alexis Oliveros (Don Tío)',
      },
      {
        id: 'hist-10',
        fromStatus: 'LISTA PARA ENTREGAR',
        toStatus: 'ENTREGADA',
        changedAt: '2026-10-25T11:20:00.000Z',
        changedBy: 'Alexis Oliveros (Don Tío)',
        reason: 'Cliente retiró y pagó saldo restante en efectivo.',
      },
    ],
    payments: [
      {
        id: 'pay-4',
        date: '2026-10-21T10:10:00.000Z',
        amount: 40000,
        paymentMethod: 'TRANSFERENCIA',
        registeredBy: 'Carlos Mario Restrepo',
        notes: 'Abono inicial Bancolombia',
      },
      {
        id: 'pay-5',
        date: '2026-10-25T11:20:00.000Z',
        amount: 47000,
        paymentMethod: 'EFECTIVO',
        registeredBy: 'Alexis Oliveros (Don Tío)',
        notes: 'Cancelación final al retirar calzado',
      },
    ],
    deliveryDetails: {
      deliveredAt: '2026-10-25T11:20:00.000Z',
      deliveredBy: 'Alexis Oliveros (Don Tío)',
      receivedByName: 'Andrés Felipe Cardona',
      adminAuthorizedDebt: false,
    },
    createdAt: '2026-10-21T10:10:00.000Z',
    updatedAt: '2026-10-25T11:20:00.000Z',
  },
];

export class StorageService {
  private static load<T>(key: string, defaultValue: T): T {
    try {
      const data = localStorage.getItem(key);
      if (!data) return defaultValue;
      return JSON.parse(data) as T;
    } catch (e) {
      console.warn(`Error loading key ${key} from storage:`, e);
      return defaultValue;
    }
  }

  private static save<T>(key: string, value: T): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error(`Error saving key ${key} to storage:`, e);
    }
  }

  // Active User / Session Simulation
  static getActiveUser(): StaffMember {
    const user = this.load<StaffMember | null>(STORAGE_KEYS.ACTIVE_USER, null);
    if (user) return user;
    const defaultUser = INITIAL_STAFF[0]; // Don Tío (Admin)
    this.save(STORAGE_KEYS.ACTIVE_USER, defaultUser);
    return defaultUser;
  }

  static setActiveUser(staff: StaffMember): void {
    this.save(STORAGE_KEYS.ACTIVE_USER, staff);
  }

  // Staff Management
  static getStaff(): StaffMember[] {
    const list = this.load<StaffMember[]>(STORAGE_KEYS.STAFF, []);
    if (!list.length) {
      this.save(STORAGE_KEYS.STAFF, INITIAL_STAFF);
      return INITIAL_STAFF;
    }
    return list;
  }

  static saveStaff(staff: StaffMember): void {
    const all = this.getStaff();
    const index = all.findIndex((s) => s.id === staff.id);
    if (index >= 0) {
      all[index] = staff;
    } else {
      all.push(staff);
    }
    this.save(STORAGE_KEYS.STAFF, all);
  }

  // Service Catalog
  static getServices(): ServiceCatalogItem[] {
    const list = this.load<ServiceCatalogItem[]>(STORAGE_KEYS.SERVICES, []);
    if (!list.length) {
      this.save(STORAGE_KEYS.SERVICES, INITIAL_SERVICES);
      return INITIAL_SERVICES;
    }
    return list;
  }

  static saveService(service: ServiceCatalogItem): void {
    const all = this.getServices();
    const index = all.findIndex((s) => s.id === service.id);
    if (index >= 0) {
      all[index] = service;
    } else {
      all.push(service);
    }
    this.save(STORAGE_KEYS.SERVICES, all);
  }

  static deleteService(id: string): void {
    const all = this.getServices();
    const filtered = all.filter((s) => s.id !== id);
    this.save(STORAGE_KEYS.SERVICES, filtered);
  }

  // Client Management
  static getClients(): Client[] {
    const list = this.load<Client[]>(STORAGE_KEYS.CLIENTS, []);
    if (!list.length) {
      this.save(STORAGE_KEYS.CLIENTS, INITIAL_CLIENTS);
      return INITIAL_CLIENTS;
    }
    return list;
  }

  static getClientById(id: string): Client | undefined {
    return this.getClients().find((c) => c.id === id);
  }

  static saveClient(client: Client): Client {
    const all = this.getClients();
    const index = all.findIndex((c) => c.id === client.id);
    if (index >= 0) {
      all[index] = { ...all[index], ...client };
      this.save(STORAGE_KEYS.CLIENTS, all);
      return all[index];
    } else {
      const newClient = {
        ...client,
        id: client.id || `cli-${Date.now()}`,
        createdAt: client.createdAt || new Date().toISOString(),
        repairCount: client.repairCount || 0,
      };
      all.unshift(newClient);
      this.save(STORAGE_KEYS.CLIENTS, all);
      return newClient;
    }
  }

  static searchClients(query: string): Client[] {
    const clean = query.trim().toLowerCase();
    if (!clean) return this.getClients();
    return this.getClients().filter(
      (c) =>
        c.fullName.toLowerCase().includes(clean) ||
        c.phone.replace(/\D/g, '').includes(clean)
    );
  }

  // Order Management
  static getOrders(): RepairOrder[] {
    const list = this.load<RepairOrder[]>(STORAGE_KEYS.ORDERS, []);
    if (!list.length) {
      this.save(STORAGE_KEYS.ORDERS, INITIAL_ORDERS);
      this.save(STORAGE_KEYS.NEXT_ORDER_NUM, 1005);
      return INITIAL_ORDERS;
    }
    return list;
  }

  static getOrderById(id: string): RepairOrder | undefined {
    return this.getOrders().find((o) => o.id === id);
  }

  static getNextOrderCode(): string {
    const next = this.load<number>(STORAGE_KEYS.NEXT_ORDER_NUM, 1005);
    return `ORD-${next}`;
  }

  static createOrder(orderData: Omit<RepairOrder, 'id' | 'createdAt' | 'updatedAt' | 'statusHistory'>): RepairOrder {
    const currentNum = this.load<number>(STORAGE_KEYS.NEXT_ORDER_NUM, 1005);
    const orderId = `ORD-${currentNum}`;
    this.save(STORAGE_KEYS.NEXT_ORDER_NUM, currentNum + 1);

    const now = new Date().toISOString();
    const activeUser = this.getActiveUser();

    const initialHistoryEntry = {
      id: `hist-${Date.now()}`,
      toStatus: orderData.status || ('RECIBIDA' as OrderStatus),
      changedAt: now,
      changedBy: activeUser.name,
      reason: `Creación de orden en taller. Abono inicial: $${orderData.paidAmount.toLocaleString('es-CO')}`,
    };

    const newOrder: RepairOrder = {
      ...orderData,
      id: orderId,
      statusHistory: [initialHistoryEntry],
      createdAt: now,
      updatedAt: now,
    };

    const allOrders = this.getOrders();
    allOrders.unshift(newOrder);
    this.save(STORAGE_KEYS.ORDERS, allOrders);

    // Increment client repair count
    const client = this.getClientById(orderData.clientId);
    if (client) {
      client.repairCount = (client.repairCount || 0) + 1;
      this.saveClient(client);
    }

    return newOrder;
  }

  static updateOrderStatus(
    orderId: string,
    newStatus: OrderStatus,
    reason?: string,
    deliveryDetails?: {
      deliveredBy: string;
      receivedByName?: string;
      adminAuthorizedDebt?: boolean;
      adminAuthorizationReason?: string;
    }
  ): RepairOrder {
    const all = this.getOrders();
    const index = all.findIndex((o) => o.id === orderId);
    if (index === -1) throw new Error('Orden no encontrada');

    const order = all[index];
    const prevStatus = order.status;
    const now = new Date().toISOString();
    const activeUser = this.getActiveUser();

    order.status = newStatus;
    order.updatedAt = now;

    order.statusHistory.push({
      id: `hist-${Date.now()}`,
      fromStatus: prevStatus,
      toStatus: newStatus,
      changedAt: now,
      changedBy: activeUser.name,
      reason: reason || `Cambio de estado a ${newStatus}`,
    });

    if (newStatus === 'ENTREGADA') {
      order.deliveryDetails = {
        deliveredAt: now,
        deliveredBy: deliveryDetails?.deliveredBy || activeUser.name,
        receivedByName: deliveryDetails?.receivedByName || order.clientName,
        adminAuthorizedDebt: deliveryDetails?.adminAuthorizedDebt || false,
        adminAuthorizationReason: deliveryDetails?.adminAuthorizationReason,
      };
    }

    all[index] = order;
    this.save(STORAGE_KEYS.ORDERS, all);
    return order;
  }

  static addOrderPayment(
    orderId: string,
    payment: {
      amount: number;
      paymentMethod: PaymentMethod;
      reference?: string;
      notes?: string;
      registeredBy?: string;
    }
  ): RepairOrder {
    const all = this.getOrders();
    const index = all.findIndex((o) => o.id === orderId);
    if (index === -1) throw new Error('Orden no encontrada');

    const order = all[index];
    const activeUser = this.getActiveUser();
    const now = new Date().toISOString();

    if (payment.amount <= 0) {
      throw new Error('El valor del pago debe ser mayor a cero.');
    }

    if (payment.amount > order.balanceAmount) {
      throw new Error(`El abono ($${payment.amount.toLocaleString('es-CO')}) no puede exceder el saldo pendiente ($${order.balanceAmount.toLocaleString('es-CO')}).`);
    }

    const newPayment: OrderPayment = {
      id: `pay-${Date.now()}`,
      date: now,
      amount: payment.amount,
      paymentMethod: payment.paymentMethod,
      reference: payment.reference,
      registeredBy: payment.registeredBy || activeUser.name,
      notes: payment.notes,
    };

    order.payments.push(newPayment);
    order.paidAmount += payment.amount;
    order.balanceAmount = Math.max(0, order.totalAmount - order.paidAmount);
    order.updatedAt = now;

    // Log in history
    order.statusHistory.push({
      id: `hist-${Date.now()}`,
      toStatus: order.status,
      changedAt: now,
      changedBy: activeUser.name,
      reason: `Pago recibido: $${payment.amount.toLocaleString('es-CO')} vía ${payment.paymentMethod}. Saldo restante: $${order.balanceAmount.toLocaleString('es-CO')}`,
    });

    all[index] = order;
    this.save(STORAGE_KEYS.ORDERS, all);
    return order;
  }

  // Financial Metrics
  static getFinancialSummary(): FinancialSummary {
    const orders = this.getOrders();
    let totalPendingBalance = 0;
    let totalRevenueCollected = 0;
    let todayRevenue = 0;
    const todayStr = new Date().toISOString().split('T')[0];

    let receivedCount = 0;
    let inProcessCount = 0;
    let readyCount = 0;
    let deliveredCount = 0;
    let cancelledCount = 0;

    for (const ord of orders) {
      if (ord.status === 'RECIBIDA') receivedCount++;
      else if (ord.status === 'EN PROCESO') inProcessCount++;
      else if (ord.status === 'LISTA PARA ENTREGAR') readyCount++;
      else if (ord.status === 'ENTREGADA') deliveredCount++;
      else if (ord.status === 'CANCELADA') cancelledCount++;

      // Non-cancelled orders calculate balance
      if (ord.status !== 'CANCELADA') {
        totalPendingBalance += ord.balanceAmount;
      }

      // Collect all payments
      for (const p of ord.payments) {
        totalRevenueCollected += p.amount;
        if (p.date.startsWith(todayStr)) {
          todayRevenue += p.amount;
        }
      }
    }

    return {
      receivedCount,
      inProcessCount,
      readyCount,
      deliveredCount,
      cancelledCount,
      totalOrders: orders.length,
      totalPendingBalance,
      totalRevenueCollected,
      todayRevenue,
    };
  }

  // Demo Data Reset
  static resetToDemoData(): void {
    localStorage.removeItem(STORAGE_KEYS.ORDERS);
    localStorage.removeItem(STORAGE_KEYS.CLIENTS);
    localStorage.removeItem(STORAGE_KEYS.SERVICES);
    localStorage.removeItem(STORAGE_KEYS.STAFF);
    localStorage.removeItem(STORAGE_KEYS.ACTIVE_USER);
    localStorage.removeItem(STORAGE_KEYS.NEXT_ORDER_NUM);

    this.getServices();
    this.getStaff();
    this.getClients();
    this.getOrders();
    this.getActiveUser();
  }

  // Backup & JSON Export
  static exportDataJSON(): string {
    const data = {
      exportedAt: new Date().toISOString(),
      shop: 'Zapatería El Tío',
      orders: this.getOrders(),
      clients: this.getClients(),
      services: this.getServices(),
      staff: this.getStaff(),
    };
    return JSON.stringify(data, null, 2);
  }
}

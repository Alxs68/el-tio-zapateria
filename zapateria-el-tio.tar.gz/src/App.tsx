import React, { useState, useEffect } from 'react';
import { 
  RepairOrder, 
  Client, 
  ServiceCatalogItem, 
  StaffMember, 
  FinancialSummary, 
  OrderStatus, 
  PaymentMethod 
} from './types';
import { StorageService } from './services/storage';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { Dashboard } from './components/Dashboard';
import { OrderReceptionModal } from './components/OrderReceptionModal';
import { OrderDetailsModal } from './components/OrderDetailsModal';
import { ClientsView } from './components/ClientsView';
import { CatalogView } from './components/CatalogView';
import { ReportsView } from './components/ReportsView';
import { QuickSearchModal } from './components/QuickSearchModal';
import { ArchitectureInfoModal } from './components/ArchitectureInfoModal';
import { UserManualModal } from './components/UserManualModal';
import { formatCOP, getOrderStatusMeta, getShoeTypeLabel, formatDate } from './utils/formatters';
import { Search, PlusCircle, Filter, CheckCircle2, AlertCircle } from 'lucide-react';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<'dashboard' | 'orders' | 'clients' | 'catalog' | 'reports'>('dashboard');

  // Application Data States
  const [orders, setOrders] = useState<RepairOrder[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [services, setServices] = useState<ServiceCatalogItem[]>([]);
  const [staffList, setStaffList] = useState<StaffMember[]>([]);
  const [activeUser, setActiveUser] = useState<StaffMember>(() => StorageService.getActiveUser());
  const [summary, setSummary] = useState<FinancialSummary>(() => StorageService.getFinancialSummary());

  // Modal Controls
  const [isNewOrderModalOpen, setIsNewOrderModalOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<RepairOrder | null>(null);
  const [isOrderDetailsModalOpen, setIsOrderDetailsModalOpen] = useState(false);
  const [isQuickSearchModalOpen, setIsQuickSearchModalOpen] = useState(false);
  const [isArchitectureModalOpen, setIsArchitectureModalOpen] = useState(false);
  const [isUserManualOpen, setIsUserManualOpen] = useState(false);

  // Orders View Filter
  const [orderListStatusFilter, setOrderListStatusFilter] = useState<OrderStatus | 'ALL'>('ALL');
  const [orderListSearchQuery, setOrderListSearchQuery] = useState('');

  // Toast notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Load Initial Data
  const refreshAllData = () => {
    const loadedOrders = StorageService.getOrders();
    const loadedClients = StorageService.getClients();
    const loadedServices = StorageService.getServices();
    const loadedStaff = StorageService.getStaff();
    const currentUser = StorageService.getActiveUser();
    const financialSummary = StorageService.getFinancialSummary();

    setOrders(loadedOrders);
    setClients(loadedClients);
    setServices(loadedServices);
    setStaffList(loadedStaff);
    setActiveUser(currentUser);
    setSummary(financialSummary);

    // If modal is open, refresh selectedOrder
    if (selectedOrder) {
      const refreshed = loadedOrders.find((o) => o.id === selectedOrder.id);
      if (refreshed) setSelectedOrder(refreshed);
    }
  };

  useEffect(() => {
    refreshAllData();
  }, []);

  // Handlers
  const handleSaveNewOrder = (
    orderData: Omit<RepairOrder, 'id' | 'createdAt' | 'updatedAt' | 'statusHistory'>
  ) => {
    const created = StorageService.createOrder(orderData);
    refreshAllData();
    showToast(`Orden ${created.id} registrada exitosamente.`);
    setSelectedOrder(created);
    setIsOrderDetailsModalOpen(true);
  };

  const handleQuickCreateClient = (
    clientData: Omit<Client, 'id' | 'createdAt' | 'repairCount'>
  ): Client => {
    const created = StorageService.saveClient(clientData as Client);
    refreshAllData();
    return created;
  };

  const handleUpdateOrderStatus = (
    orderId: string,
    newStatus: OrderStatus,
    reason?: string,
    deliveryDetails?: {
      deliveredBy: string;
      receivedByName?: string;
      adminAuthorizedDebt?: boolean;
      adminAuthorizationReason?: string;
    }
  ) => {
    const updated = StorageService.updateOrderStatus(orderId, newStatus, reason, deliveryDetails);
    refreshAllData();
    setSelectedOrder(updated);
    showToast(`Orden ${orderId} actualizada a estado: ${newStatus}`);
  };

  const handleAddPayment = (
    orderId: string,
    payment: {
      amount: number;
      paymentMethod: PaymentMethod;
      reference?: string;
      notes?: string;
    }
  ) => {
    const updated = StorageService.addOrderPayment(orderId, payment);
    refreshAllData();
    setSelectedOrder(updated);
    showToast(`Abono de ${formatCOP(payment.amount)} registrado en orden ${orderId}.`);
  };

  const handleSaveClient = (client: Client) => {
    StorageService.saveClient(client);
    refreshAllData();
    showToast(`Cliente ${client.fullName} guardado.`);
  };

  const handleSaveService = (service: ServiceCatalogItem) => {
    StorageService.saveService(service);
    refreshAllData();
    showToast(`Servicio "${service.name}" actualizado.`);
  };

  const handleDeleteService = (id: string) => {
    StorageService.deleteService(id);
    refreshAllData();
    showToast('Servicio eliminado del catálogo.');
  };

  const handleSwitchUser = (staff: StaffMember) => {
    StorageService.setActiveUser(staff);
    setActiveUser(staff);
    showToast(`Usuario activo cambiado a: ${staff.name} (${staff.role})`);
  };

  const handleResetDemoData = () => {
    StorageService.resetToDemoData();
    refreshAllData();
    showToast('Datos de muestra de Zapatería El Tío restaurados con éxito.');
  };

  const handleExportJSON = () => {
    const jsonStr = StorageService.exportDataJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `zapateria-el-tio-backup-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
    showToast('Copia de respaldo JSON descargada.');
  };

  const handleOpenOrderDetails = (order: RepairOrder) => {
    setSelectedOrder(order);
    setIsOrderDetailsModalOpen(true);
  };

  // Orders list filter
  const filteredOrderList = orders.filter((ord) => {
    const matchesStatus = orderListStatusFilter === 'ALL' || ord.status === orderListStatusFilter;
    const clean = orderListSearchQuery.trim().toLowerCase();
    if (!clean) return matchesStatus;

    const matchesSearch =
      ord.id.toLowerCase().includes(clean) ||
      ord.clientName.toLowerCase().includes(clean) ||
      ord.clientPhone.includes(clean) ||
      ord.lockerLocation.toLowerCase().includes(clean) ||
      ord.description.toLowerCase().includes(clean);

    return matchesStatus && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-[#faf9f6] text-stone-900 flex flex-col font-sans">
      
      {/* Top Bar Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeUser={activeUser}
        staffList={staffList}
        onSwitchUser={handleSwitchUser}
        onOpenNewOrder={() => setIsNewOrderModalOpen(true)}
        onOpenQuickSearch={() => setIsQuickSearchModalOpen(true)}
        onOpenArchitectureModal={() => setIsArchitectureModalOpen(true)}
        onOpenUserManual={() => setIsUserManualOpen(true)}
        onResetDemoData={handleResetDemoData}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 pt-5 pb-16">
        
        {/* View 1: Dashboard Tab */}
        {activeTab === 'dashboard' && (
          <Dashboard
            orders={orders}
            summary={summary}
            onOpenOrder={handleOpenOrderDetails}
            onOpenNewOrder={() => setIsNewOrderModalOpen(true)}
            onSearchOrders={() => setIsQuickSearchModalOpen(true)}
            onOpenUserManual={() => setIsUserManualOpen(true)}
          />
        )}

        {/* View 2: All Orders & Tracking Tab */}
        {activeTab === 'orders' && (
          <div className="space-y-6 pb-20 lg:pb-8">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-stone-900 tracking-tight">
                  Gestión & Seguimiento de Reparaciones
                </h2>
                <p className="text-xs text-stone-600 mt-0.5">
                  Consulta de órdenes por número, cliente, teléfono, estado o casillero físico.
                </p>
              </div>

              <button
                onClick={() => setIsNewOrderModalOpen(true)}
                className="bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold px-4 py-2.5 rounded-xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs transition-transform active:scale-95"
              >
                <PlusCircle className="w-4 h-4 text-stone-950" />
                <span>Registrar Calzado</span>
              </button>
            </div>

            {/* Filter Bar */}
            <div className="bg-white rounded-2xl border border-stone-200 p-4 shadow-2xs space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-1.5 p-1 bg-stone-100 rounded-xl overflow-x-auto scroll-touch">
                  {(['ALL', 'RECIBIDA', 'EN PROCESO', 'LISTA PARA ENTREGAR', 'ENTREGADA', 'CANCELADA'] as const).map((st) => (
                    <button
                      key={st}
                      onClick={() => setOrderListStatusFilter(st)}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                        orderListStatusFilter === st
                          ? 'bg-stone-900 text-white shadow-xs'
                          : 'text-stone-600 hover:text-stone-900'
                      }`}
                    >
                      {st === 'ALL' ? 'Todas las órdenes' : st}
                    </button>
                  ))}
                </div>

                <div className="relative min-w-[240px]">
                  <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Filtrar por orden, cliente, casillero..."
                    value={orderListSearchQuery}
                    onChange={(e) => setOrderListSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                  {orderListSearchQuery && (
                    <button
                      onClick={() => setOrderListSearchQuery('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 text-xs font-bold"
                    >
                      ✕
                    </button>
                  )}
                </div>
              </div>

              {/* Table View */}
              <div className="border border-stone-200 rounded-xl overflow-x-auto">
                <table className="w-full text-left text-xs min-w-[750px]">
                  <thead className="bg-stone-100 border-b border-stone-200 text-stone-600 font-semibold">
                    <tr>
                      <th className="py-2.5 px-3">Nro. Orden</th>
                      <th className="py-2.5 px-3">Cliente & Contacto</th>
                      <th className="py-2.5 px-3">Calzado & Trabajo</th>
                      <th className="py-2.5 px-3">Ubicación / Casillero</th>
                      <th className="py-2.5 px-3">Estado</th>
                      <th className="py-2.5 px-3 text-right">Total</th>
                      <th className="py-2.5 px-3 text-right">Saldo</th>
                      <th className="py-2.5 px-3 text-center">Acción</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-200 bg-white">
                    {filteredOrderList.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="py-8 text-center text-stone-500">
                          No se encontraron órdenes con los filtros seleccionados.
                        </td>
                      </tr>
                    ) : (
                      filteredOrderList.map((ord) => {
                        const meta = getOrderStatusMeta(ord.status);
                        return (
                          <tr key={ord.id} className="hover:bg-stone-50 transition-colors">
                            <td className="py-3 px-3 font-mono font-bold text-stone-900">
                              {ord.id}
                            </td>
                            <td className="py-3 px-3">
                              <span className="font-bold text-stone-900 block">{ord.clientName}</span>
                              <span className="text-[11px] text-stone-500">{ord.clientPhone}</span>
                            </td>
                            <td className="py-3 px-3">
                              <span className="font-medium text-stone-800 block">{getShoeTypeLabel(ord.shoeType)}</span>
                              <span className="text-[11px] text-stone-500 line-clamp-1">{ord.description}</span>
                            </td>
                            <td className="py-3 px-3">
                              <span className="font-semibold text-amber-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 text-[11px]">
                                {ord.lockerLocation}
                              </span>
                            </td>
                            <td className="py-3 px-3">
                              <span className={`px-2 py-0.5 text-[11px] font-bold rounded border ${meta.badgeBg} ${meta.badgeText} ${meta.borderColor}`}>
                                {meta.label}
                              </span>
                            </td>
                            <td className="py-3 px-3 text-right font-mono tabular-nums text-stone-800">
                              {formatCOP(ord.totalAmount)}
                            </td>
                            <td className="py-3 px-3 text-right font-mono font-bold tabular-nums">
                              {ord.balanceAmount > 0 ? (
                                <span className="text-red-600">{formatCOP(ord.balanceAmount)}</span>
                              ) : (
                                <span className="text-emerald-700">Paz y Salvo</span>
                              )}
                            </td>
                            <td className="py-3 px-3 text-center">
                              <button
                                onClick={() => handleOpenOrderDetails(ord)}
                                className="px-2.5 py-1 bg-stone-900 text-white rounded-lg text-[11px] font-semibold hover:bg-stone-800 transition-colors"
                              >
                                Ver Detalle
                              </button>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* View 3: Clients Directory Tab */}
        {activeTab === 'clients' && (
          <ClientsView
            clients={clients}
            orders={orders}
            onSaveClient={handleSaveClient}
            onSelectOrder={handleOpenOrderDetails}
          />
        )}

        {/* View 4: Services & Rates Catalog Tab */}
        {activeTab === 'catalog' && (
          <CatalogView
            services={services}
            activeUser={activeUser}
            onSaveService={handleSaveService}
            onDeleteService={handleDeleteService}
          />
        )}

        {/* View 5: Financial Reports Tab */}
        {activeTab === 'reports' && (
          <ReportsView
            orders={orders}
            summary={summary}
            services={services}
            onSelectOrder={handleOpenOrderDetails}
            onExportJSON={handleExportJSON}
            onResetDemoData={handleResetDemoData}
          />
        )}

      </main>

      {/* Mobile Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenNewOrder={() => setIsNewOrderModalOpen(true)}
      />

      {/* Reception / New Order Modal */}
      <OrderReceptionModal
        isOpen={isNewOrderModalOpen}
        onClose={() => setIsNewOrderModalOpen(false)}
        nextOrderCode={StorageService.getNextOrderCode()}
        clients={clients}
        services={services}
        staffList={staffList}
        activeUser={activeUser}
        onSaveOrder={handleSaveNewOrder}
        onQuickCreateClient={handleQuickCreateClient}
      />

      {/* Order Details & Workflow Sheet Modal */}
      <OrderDetailsModal
        order={selectedOrder}
        isOpen={isOrderDetailsModalOpen}
        onClose={() => {
          setIsOrderDetailsModalOpen(false);
          setSelectedOrder(null);
        }}
        activeUser={activeUser}
        onUpdateStatus={handleUpdateOrderStatus}
        onAddPayment={handleAddPayment}
      />

      {/* Quick Search Modal */}
      <QuickSearchModal
        isOpen={isQuickSearchModalOpen}
        onClose={() => setIsQuickSearchModalOpen(false)}
        orders={orders}
        clients={clients}
        onSelectOrder={handleOpenOrderDetails}
        onSelectClient={(c) => {
          setActiveTab('clients');
        }}
      />

      {/* Architecture & Delivery Audit Info Modal */}
      <ArchitectureInfoModal
        isOpen={isArchitectureModalOpen}
        onClose={() => setIsArchitectureModalOpen(false)}
      />

      {/* User Manual Modal for Dad / Workshop */}
      <UserManualModal
        isOpen={isUserManualOpen}
        onClose={() => setIsUserManualOpen(false)}
      />

      {/* Toast Alert Banner */}
      {toastMessage && (
        <div className="fixed bottom-20 lg:bottom-6 right-6 z-50 bg-stone-900 text-stone-100 text-xs sm:text-sm font-semibold px-4 py-2.5 rounded-xl shadow-xl border border-stone-800 flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

    </div>
  );
}
